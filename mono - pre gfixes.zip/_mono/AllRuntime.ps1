# ==============================================================================
# Axiom-Phoenix v4.0 - All Runtime (Load Last)
# TUI engine, screen management, and main application loop
# ==============================================================================

#region Global State

# Initialize global TUI state
$global:TuiState = @{
    Running = $false
    BufferWidth = 0
    BufferHeight = 0
    CompositorBuffer = $null
    PreviousCompositorBuffer = $null
    ScreenStack = [System.Collections.Generic.Stack[Screen]]::new() # CHANGED TO GENERIC STACK
    CurrentScreen = $null
    IsDirty = $true
    FocusedComponent = $null
    CommandPalette = $null
    Services = @{}
    LastRenderTime = [datetime]::Now
    FrameCount = 0
    InputQueue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[System.ConsoleKeyInfo]'
    OverlayStack = [System.Collections.Generic.List[UIElement]]::new() # CHANGED TO GENERIC LIST
    # Added for input thread management
    CancellationTokenSource = $null
    InputRunspace = $null
    InputPowerShell = $null
    InputAsyncResult = $null
}

#endregion

#region Error Handling

function Invoke-WithErrorHandling {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Component,
        
        [Parameter(Mandatory)]
        [string]$Context,
        
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,
        
        [hashtable]$AdditionalData = @{}
    )
    
    try {
        & $ScriptBlock
    }
    catch {
        $errorDetails = @{
            Component = $Component
            Context = $Context
            ErrorMessage = $_.Exception.Message
            ErrorType = $_.Exception.GetType().FullName
            StackTrace = $_.ScriptStackTrace
            Timestamp = [datetime]::Now
        }
        
        foreach ($key in $AdditionalData.Keys) {
            $errorDetails[$key] = $AdditionalData[$key]
        }
        
        $logger = $global:TuiState.Services.Logger
        if ($logger) {
            $logger.Log("Error", "Error in $Component during $Context : $($_.Exception.Message)")
            $logger.Log("Debug", "Error details: $($errorDetails | ConvertTo-Json -Compress)")
        }
        
        # Re-throw for caller to handle if needed
        throw
    }
}

#endregion

#region Engine Management

function Initialize-TuiEngine {
    [CmdletBinding()]
    param()
    
    try {
        Write-Log -Level Info -Message "Initializing TUI engine..."
        
        # Store original console state
        $global:TuiState.OriginalWindowTitle = $Host.UI.RawUI.WindowTitle
        $global:TuiState.OriginalCursorVisible = [Console]::CursorVisible
        
        # Configure console
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        [Console]::CursorVisible = $false
        $Host.UI.RawUI.WindowTitle = "Axiom-Phoenix v4.0 TUI Framework"
        
        # Clear screen and hide cursor
        Clear-Host
        [Console]::SetCursorPosition(0, 0)
        
        # Get initial size
        Update-TuiEngineSize
        
        # Create compositor buffers
        $width = $global:TuiState.BufferWidth
        $height = $global:TuiState.BufferHeight
        $global:TuiState.CompositorBuffer = [TuiBuffer]::new($width, $height, "Compositor")
        $global:TuiState.PreviousCompositorBuffer = [TuiBuffer]::new($width, $height, "PreviousCompositor")
        
        # Clear with theme background
        $bgColor = Get-ThemeColor("Background")
        $global:TuiState.CompositorBuffer.Clear([TuiCell]::new(' ', $bgColor, $bgColor))
        $global:TuiState.PreviousCompositorBuffer.Clear([TuiCell]::new(' ', $bgColor, $bgColor))
        
        Write-Log -Level Info -Message "TUI engine initialized. Buffer size: ${width}x${height}"
    }
    catch {
        Invoke-WithErrorHandling -Component "TuiEngine" -Context "Initialization" -ScriptBlock { throw } `
            -AdditionalData @{ Phase = "EngineInit" }
    }
}

function Start-TuiEngine {
    [CmdletBinding()]
    param()
    
    try {
        Write-Verbose "Starting TUI Engine main loop..."
        
        $global:TuiState.Running = $true
        $frameTimer = [System.Diagnostics.Stopwatch]::new()
        
        while ($global:TuiState.Running) {
            $frameTimer.Restart()
            
            # Check for resize
            if ([Console]::WindowWidth -ne $global:TuiState.BufferWidth -or 
                [Console]::WindowHeight -ne $global:TuiState.BufferHeight) {
                Update-TuiEngineSize
            }
            
            # Process input
            Process-TuiInput
            
            # Render if dirty
            if ($global:TuiState.IsDirty) {
                Invoke-TuiRender
                $global:TuiState.IsDirty = $false
            }
            
            # Frame timing (target 60 FPS)
            $frameTimer.Stop()
            $frameTime = $frameTimer.ElapsedMilliseconds
            if ($frameTime -lt 16) {
                Start-Sleep -Milliseconds (16 - $frameTime)
            }
            
            $global:TuiState.FrameCount++
        }
        
        Write-Verbose "TUI Engine stopped after $($global:TuiState.FrameCount) frames"
    }
    catch {
        Write-Error "TUI Engine error: $_"
        Invoke-PanicHandler $_
    }
    finally {
        Stop-TuiEngine
    }
}

function Stop-TuiEngine {
    [CmdletBinding()]
    param()
    
    try {
        Write-Verbose "Stopping TUI Engine..."
        
        $global:TuiState.Running = $false
        
        # Cleanup current screen
        if ($global:TuiState.CurrentScreen) {
            try {
                $global:TuiState.CurrentScreen.OnExit()
                $global:TuiState.CurrentScreen.Cleanup()
            }
            catch {
                Write-Warning "Error cleaning up current screen: $_"
            }
        }
        
        # Cleanup services
        foreach ($service in $global:TuiState.Services.Values) {
            if ($service -and $service.PSObject.Methods.Match('Cleanup')) {
                try {
                    $service.Cleanup()
                }
                catch {
                    Write-Warning "Error cleaning up service: $_"
                }
            }
        }
        
        # Restore console
        [Console]::CursorVisible = $true
        [Console]::Clear()
        [Console]::SetCursorPosition(0, 0)
        
        Write-Verbose "TUI Engine stopped and cleaned up"
    }
    catch {
        Write-Error "Error stopping TUI engine: $_"
    }
}

function Update-TuiEngineSize {
    [CmdletBinding()]
    param()
    
    try {
        $newWidth = [Console]::WindowWidth
        $newHeight = [Console]::WindowHeight
        
        Write-Verbose "Console resized from $($global:TuiState.BufferWidth)x$($global:TuiState.BufferHeight) to ${newWidth}x${newHeight}"
        
        # Update state
        $global:TuiState.BufferWidth = $newWidth
        $global:TuiState.BufferHeight = $newHeight
        
        # Resize compositor buffers
        $global:TuiState.CompositorBuffer.Resize($newWidth, $newHeight)
        $global:TuiState.PreviousCompositorBuffer.Resize($newWidth, $newHeight)
        
        # Resize current screen
        if ($global:TuiState.CurrentScreen) {
            $global:TuiState.CurrentScreen.Resize($newWidth, $newHeight)
        }
        
        # Force full redraw
        $global:TuiState.IsDirty = $true
        [Console]::Clear()
    }
    catch {
        Write-Error "Failed to update engine size: $_"
    }
}

#endregion

#region Rendering System

function Invoke-TuiRender {
    [CmdletBinding()]
    param()
    
    try {
        $renderTimer = [System.Diagnostics.Stopwatch]::StartNew()
        
        # Clear compositor buffer
        $global:TuiState.CompositorBuffer.Clear()
        
        Write-Verbose "Starting render frame $($global:TuiState.FrameCount)"
        
        # Render current screen
        if ($global:TuiState.CurrentScreen) {
            try {
                # Render the screen which will update its internal buffer
                $global:TuiState.CurrentScreen.Render()
                
                # Get the screen's buffer
                $screenBuffer = $global:TuiState.CurrentScreen.GetBuffer()
                
                if ($screenBuffer) {
                    # Blend screen buffer into compositor
                    $global:TuiState.CompositorBuffer.BlendBuffer($screenBuffer, 0, 0)
                }
                else {
                    Write-Warning "Screen buffer is null for $($global:TuiState.CurrentScreen.Name)"
                }
            }
            catch {
                Write-Error "Error rendering screen: $_"
                throw
            }
            
            # Render command palette if visible
            if ($global:TuiState.CommandPalette -and $global:TuiState.CommandPalette.Visible) {
                try {
                    $global:TuiState.CommandPalette.Render()
                    $paletteBuffer = $global:TuiState.CommandPalette.GetBuffer()
                    if ($paletteBuffer) {
                        # Command palette position was set during initialization
                        $global:TuiState.CompositorBuffer.BlendBuffer($paletteBuffer, 
                            $global:TuiState.CommandPalette.X,
                            $global:TuiState.CommandPalette.Y
                        )
                    }
                }
                catch {
                    Write-Warning "Error rendering command palette: $_"
                }
            }
            
            # Render overlays
            if ($global:TuiState.ContainsKey('OverlayStack') -and $global:TuiState.OverlayStack -and @($global:TuiState.OverlayStack).Count -gt 0) {
                foreach ($overlay in $global:TuiState.OverlayStack) {
                    if ($overlay -and $overlay.Visible) {
                        $overlay.Render()
                        $overlayBuffer = $overlay.GetBuffer()
                        if ($overlayBuffer) {
                            $global:TuiState.CompositorBuffer.BlendBuffer($overlayBuffer, $overlay.X, $overlay.Y)
                        }
                    }
                }
            }
        }
        
        # Debug: Add a test message to see if rendering is working
        if ($global:TuiState.FrameCount -eq 0) {
            $testMsg = "RENDERING IS WORKING - Frame: $($global:TuiState.FrameCount)"
            $global:TuiState.CompositorBuffer.WriteString(2, 2, $testMsg, @{ FG = "#FFFF00"; BG = "#000000" })
        }
        
        # Force full redraw on first frame by making previous buffer different
        if ($global:TuiState.FrameCount -eq 0) {
            Write-Host "First frame - initializing previous buffer for differential rendering" -ForegroundColor Green
            # Fill previous buffer with different content to force full redraw
            for ($y = 0; $y -lt $global:TuiState.PreviousCompositorBuffer.Height; $y++) {
                for ($x = 0; $x -lt $global:TuiState.PreviousCompositorBuffer.Width; $x++) {
                    $global:TuiState.PreviousCompositorBuffer.SetCell($x, $y, 
                        [TuiCell]::new('?', "#404040", "#404040"))
                }
            }
        }
        
        # Differential rendering - compare current compositor to previous
        Render-DifferentialBuffer
        
        # Swap buffers for next frame
        $temp = $global:TuiState.PreviousCompositorBuffer
        $global:TuiState.PreviousCompositorBuffer = $global:TuiState.CompositorBuffer
        $global:TuiState.CompositorBuffer = $temp
        
        $renderTimer.Stop()
        
        if ($renderTimer.ElapsedMilliseconds -gt 16) {
            Write-Verbose "Slow frame: $($renderTimer.ElapsedMilliseconds)ms"
        }
    }
    catch {
        Write-Error "Render error: $_"
        throw
    }
}

function Render-DifferentialBuffer {
    [CmdletBinding()]
    param()
    
    try {
        $current = $global:TuiState.CompositorBuffer
        $previous = $global:TuiState.PreviousCompositorBuffer
        
        $ansiBuilder = [System.Text.StringBuilder]::new()
        $currentX = -1
        $currentY = -1
        $changeCount = 0
        
        for ($y = 0; $y -lt $current.Height; $y++) {
            for ($x = 0; $x -lt $current.Width; $x++) {
                $currentCell = $current.GetCell($x, $y)
                $previousCell = $previous.GetCell($x, $y)
                
                if ($currentCell.DiffersFrom($previousCell)) {
                    $changeCount++
                    
                    # Move cursor if needed
                    if ($currentX -ne $x -or $currentY -ne $y) {
                        [void]$ansiBuilder.Append("`e[$($y + 1);$($x + 1)H")
                        $currentX = $x
                        $currentY = $y
                    }
                    
                    # Use cell's ToAnsiString method which handles all styling
                    [void]$ansiBuilder.Append($currentCell.ToAnsiString())
                    $currentX++
                    
                    # Copy to previous buffer
                    $previous.SetCell($x, $y, [TuiCell]::new($currentCell))
                }
            }
        }
        
        # Log changes on first few frames
        if ($global:TuiState.FrameCount -lt 5) {
            Write-Host "Frame $($global:TuiState.FrameCount): $changeCount cells changed" -ForegroundColor Cyan
        }
        
        # Reset styling at end
        if ($ansiBuilder.Length -gt 0) {
            [void]$ansiBuilder.Append("`e[0m")
            [Console]::Write($ansiBuilder.ToString())
        }
    }
    catch {
        Write-Error "Differential rendering error: $_"
        throw
    }
}

#endregion

#region Input Processing

function Process-TuiInput {
    [CmdletBinding()]
    param()
    
    try {
        if ([Console]::KeyAvailable) {
            $keyInfo = [Console]::ReadKey($true)
            
            # Check for global command palette keybind (Ctrl+P) at the highest priority
            if ($keyInfo.Key -eq [ConsoleKey]::P -and ($keyInfo.Modifiers -band [ConsoleModifiers]::Control)) {
                if ($global:TuiState.CommandPalette) {
                    $global:TuiState.CommandPalette.Show()
                    $global:TuiState.IsDirty = $true
                    return
                }
            }

            # If there's an active overlay (like a dialog), give it priority
            if ($global:TuiState.OverlayStack.Count -gt 0) {
                $topOverlay = $global:TuiState.OverlayStack[-1]
                if ($topOverlay -and $topOverlay.Visible) {
                    if ($topOverlay.HandleInput($keyInfo)) {
                        $global:TuiState.IsDirty = $true
                        return
                    }
                }
            }
            
            # Check command palette if visible
            if ($global:TuiState.CommandPalette -and $global:TuiState.CommandPalette.Visible) {
                if ($global:TuiState.CommandPalette.HandleInput($keyInfo)) {
                    $global:TuiState.IsDirty = $true
                    return
                }
            }

            # Handle Tab for focus navigation (globally managed by FocusManager)
            if ($keyInfo.Key -eq [ConsoleKey]::Tab) {
                $focusManager = $global:TuiState.Services.FocusManager
                if ($focusManager) {
                    $reverse = ($keyInfo.Modifiers -band [ConsoleModifiers]::Shift) -ne 0
                    $focusManager.MoveFocus($reverse)
                    $global:TuiState.IsDirty = $true
                    return
                }
            }

            # Give the currently focused component a chance to handle the input
            $focusManager = $global:TuiState.Services.FocusManager
            if ($focusManager -and $focusManager.FocusedComponent) {
                if ($focusManager.FocusedComponent.HandleInput($keyInfo)) {
                    $global:TuiState.IsDirty = $true
                    return
                }
            }

            # Check global hotkeys via KeybindingService
            if ($global:TuiState.Services.KeybindingService) {
                $action = $global:TuiState.Services.KeybindingService.GetAction($keyInfo)
                if ($action) {
                    # Execute action via ActionService
                    if ($global:TuiState.Services.ActionService) {
                        try {
                            $global:TuiState.Services.ActionService.ExecuteAction($action)
                            $global:TuiState.IsDirty = $true
                            return
                        }
                        catch {
                            Write-Log -Level Warning -Message "Failed to execute action '$action' via keybinding: $($_.Exception.Message)" -Data $_
                        }
                    }
                }
            }
            
            # Finally, give the current screen a chance to handle the input
            if ($global:TuiState.CurrentScreen -and $global:TuiState.CurrentScreen.HandleInput($keyInfo)) {
                $global:TuiState.IsDirty = $true
                return
            }
        }
    }
    catch {
        Write-Error "Input processing error: $_"
    }
}
        }
    }
    catch {
        Write-Error "Input processing error: $_"
    }
}

#endregion

#region Overlay Management

function Show-TuiOverlay {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [UIElement]$Overlay
    )
    
    # Use DialogManager if the overlay is a Dialog
    if ($Overlay -is [Dialog]) {
        $dialogManager = $global:TuiState.Services.DialogManager
        if ($dialogManager) {
            $dialogManager.ShowDialog($Overlay)
            return
        }
    }
    
    # For non-dialog overlays, handle manually
    if (-not $global:TuiState.OverlayStack) {
        $global:TuiState.OverlayStack = [System.Collections.Generic.List[UIElement]]::new()
    }
    
    # Position overlay at center
    $consoleWidth = $global:TuiState.BufferWidth
    $consoleHeight = $global:TuiState.BufferHeight
    $Overlay.X = [Math]::Max(0, [Math]::Floor(($consoleWidth - $Overlay.Width) / 2))
    $Overlay.Y = [Math]::Max(0, [Math]::Floor(($consoleHeight - $Overlay.Height) / 2))
    
    $Overlay.Visible = $true
    $Overlay.IsOverlay = $true
    $global:TuiState.OverlayStack.Add($Overlay)
    $global:TuiState.IsDirty = $true
    
    # Write-Log -Level Debug -Message "Show-TuiOverlay: Displayed overlay '$($Overlay.Name)' at X=$($Overlay.X), Y=$($Overlay.Y)"
}

function Close-TopTuiOverlay {
    [CmdletBinding()]
    param()
    
    if ($global:TuiState.OverlayStack.Count -eq 0) {
        # Write-Log -Level Warning -Message "Close-TopTuiOverlay: No overlays to close"
        return
    }
    
    $topOverlay = $global:TuiState.OverlayStack[-1]
    
    # Use DialogManager if it's a Dialog
    if ($topOverlay -is [Dialog]) {
        $dialogManager = $global:TuiState.Services.DialogManager
        if ($dialogManager) {
            $dialogManager.HideDialog($topOverlay)
            return
        }
    }
    
    # Manual removal for non-dialog overlays
    $global:TuiState.OverlayStack.RemoveAt($global:TuiState.OverlayStack.Count - 1)
    $topOverlay.Visible = $false
    $topOverlay.IsOverlay = $false
    $topOverlay.Cleanup()
    $global:TuiState.IsDirty = $true
    
    # Write-Log -Level Debug -Message "Close-TopTuiOverlay: Closed overlay '$($topOverlay.Name)'"
}

#endregion

#region Error Handling

function Invoke-PanicHandler {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$Error
    )
    
    try {
        Write-Host "`n`n=== AXIOM-PHOENIX PANIC HANDLER ===" -ForegroundColor Red
        Write-Host "A critical error has occurred!" -ForegroundColor Red
        Write-Host ""
        
        # Error details
        Write-Host "Error Message:" -ForegroundColor Yellow
        Write-Host "  $($Error.Exception.Message)" -ForegroundColor White
        Write-Host ""
        
        Write-Host "Error Type:" -ForegroundColor Yellow
        Write-Host "  $($Error.Exception.GetType().FullName)" -ForegroundColor White
        Write-Host ""
        
        Write-Host "Stack Trace:" -ForegroundColor Yellow
        $Error.ScriptStackTrace -split "`n" | ForEach-Object {
            Write-Host "  $_" -ForegroundColor Gray
        }
        Write-Host ""
        
        # System info
        Write-Host "System Information:" -ForegroundColor Yellow
        Write-Host "  PowerShell: $($PSVersionTable.PSVersion)" -ForegroundColor Gray
        Write-Host "  OS: $([System.Environment]::OSVersion.VersionString)" -ForegroundColor Gray
        Write-Host "  Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
        Write-Host ""
        
        # Crash report location
        $crashReportPath = Join-Path $env:TEMP "axiom-phoenix-crash-$(Get-Date -Format 'yyyyMMdd-HHmmss').txt"
        
        $crashReport = @"
AXIOM-PHOENIX CRASH REPORT
Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

ERROR DETAILS:
$($Error | Out-String)

SYSTEM INFORMATION:
PowerShell Version: $($PSVersionTable.PSVersion)
OS Version: $([System.Environment]::OSVersion.VersionString)
CLR Version: $($PSVersionTable.CLRVersion)
Host: $($Host.Name)

GLOBAL STATE:
$($global:TuiState | ConvertTo-Json -Depth 3)
"@
        
        $crashReport | Out-File -FilePath $crashReportPath -Force
        
        Write-Host "Crash report saved to:" -ForegroundColor Yellow
        Write-Host "  $crashReportPath" -ForegroundColor Cyan
        Write-Host ""
        
        Write-Host "Press any key to exit..." -ForegroundColor White
        [Console]::ReadKey($true) | Out-Null
    }
    catch {
        Write-Host "FATAL: Panic handler failed!" -ForegroundColor Magenta
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
    finally {
        # Try to restore console
        try {
            [Console]::CursorVisible = $true
            [Console]::Clear()
        }
        catch {}
        
        # Exit
        exit 1
    }
}

#endregion

#region Panic Handler

function Invoke-PanicHandler {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$ErrorRecord
    )
    
    # Ensure we're in a safe state to write to console
    try {
        [Console]::ResetColor()
        [Console]::CursorVisible = $true
        Clear-Host
    } catch { }
    
    Write-Host "`n`n" -NoNewline
    Write-Host "================================ PANIC HANDLER ================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "An unrecoverable error has occurred:" -ForegroundColor Yellow
    Write-Host ""
    
    # Error details
    Write-Host "ERROR: " -ForegroundColor Red -NoNewline
    Write-Host $ErrorRecord.Exception.Message
    Write-Host ""
    Write-Host "TYPE: " -ForegroundColor Yellow -NoNewline
    Write-Host $ErrorRecord.Exception.GetType().FullName
    Write-Host ""
    
    # Stack trace
    Write-Host "STACK TRACE:" -ForegroundColor Yellow
    $stackLines = $ErrorRecord.ScriptStackTrace -split "`n"
    foreach ($line in $stackLines) {
        Write-Host "  $line" -ForegroundColor DarkGray
    }
    Write-Host ""
    
    # System info
    Write-Host "SYSTEM INFO:" -ForegroundColor Yellow
    Write-Host "  PowerShell: $($PSVersionTable.PSVersion)" -ForegroundColor DarkGray
    Write-Host "  Platform: $($PSVersionTable.Platform)" -ForegroundColor DarkGray
    Write-Host "  OS: $($PSVersionTable.OS)" -ForegroundColor DarkGray
    Write-Host "  Host: $($Host.Name) v$($Host.Version)" -ForegroundColor DarkGray
    Write-Host ""
    
    # Save crash report
    $crashDir = Join-Path $env:TEMP "AxiomPhoenix\Crashes"
    if (-not (Test-Path $crashDir)) {
        New-Item -ItemType Directory -Path $crashDir -Force | Out-Null
    }
    
    $crashFile = Join-Path $crashDir "crash_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    $crashReport = @{
        Timestamp = [datetime]::Now
        Error = @{
            Message = $ErrorRecord.Exception.Message
            Type = $ErrorRecord.Exception.GetType().FullName
            StackTrace = $ErrorRecord.ScriptStackTrace
            InnerException = if ($ErrorRecord.Exception.InnerException) { $ErrorRecord.Exception.InnerException.Message } else { $null }
        }
        System = @{
            PowerShell = $PSVersionTable.PSVersion.ToString()
            Platform = $PSVersionTable.Platform
            OS = $PSVersionTable.OS
            Host = "$($Host.Name) v$($Host.Version)"
        }
        GlobalState = @{
            Running = $global:TuiState.Running
            BufferSize = "$($global:TuiState.BufferWidth)x$($global:TuiState.BufferHeight)"
            CurrentScreen = if ($global:TuiState.CurrentScreen) { $global:TuiState.CurrentScreen.Name } else { "None" }
            OverlayCount = if ($global:TuiState.OverlayStack) { $global:TuiState.OverlayStack.Count } else { 0 }
        }
    }
    
    try {
        $crashReport | ConvertTo-Json -Depth 10 | Out-File -FilePath $crashFile -Encoding UTF8
        Write-Host "Crash report saved to: $crashFile" -ForegroundColor Green
    } catch {
        Write-Host "Failed to save crash report: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Write-Host ""
    Write-Host "=============================================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Press any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
    # Final cleanup
    try {
        Stop-TuiEngine -Force
    } catch { }
    
    exit 1
}

#endregion

#region Application Entry

function Start-AxiomPhoenix {
    [CmdletBinding()]
    param(
        [ServiceContainer]$ServiceContainer,
        [Screen]$InitialScreen
    )
    
    try {
        # Write-Log -Level Info -Message "Starting Axiom-Phoenix application..."
        
        # Store services
        $global:TuiState.Services = @{
            ServiceContainer = $ServiceContainer
        }
        
        # Extract key services for quick access
        $serviceNames = @(
            'ActionService', 'KeybindingService', 'NavigationService', 
            'DataManager', 'ThemeManager', 'EventManager', 'Logger', 'FocusManager', 'DialogManager' # Add new services
        )
        
        foreach ($serviceName in $serviceNames) {
            try {
                $service = $ServiceContainer.GetService($serviceName)
                if ($service) {
                    $global:TuiState.Services[$serviceName] = $service
                }
            }
            catch {
                # Write-Log -Level Warning -Message "Failed to get service '$serviceName': $($_.Exception.Message)" -Data $_
            }
        }
        
        # Create command palette if available
        $actionService = $global:TuiState.Services.ActionService
        if ($actionService) {
            $global:TuiState.CommandPalette = [CommandPalette]::new("GlobalCommandPalette", $actionService)
            $global:TuiState.CommandPalette.RefreshActions()
        }
        
        # Initialize engine
        Initialize-TuiEngine
        
        # Get the NavigationService instance directly from global state
        $navService = $global:TuiState.Services.NavigationService

        # Set initial screen using NavigationService (CRUCIAL FIX)
        if ($InitialScreen) {
            $navService.NavigateTo($InitialScreen) # Use the service directly
        }
        else {
            # Write-Log -Level Warning -Message "No initial screen provided. Application might not display anything."
        }
        
        # Start main loop
        Start-TuiEngine
    }
    catch {
        # Use Invoke-PanicHandler for critical startup errors
        Invoke-PanicHandler $_
    }
    finally {
        Stop-TuiEngine # Ensure cleanup even if startup fails
    }
}

#endregion
