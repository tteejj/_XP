# Copy the enhanced Start.ps1 file
# This updates the existing Start.ps1 with the beautiful splash screen version

# Backup the original
if (Test-Path ".\Start.ps1") {
    Copy-Item ".\Start.ps1" ".\Start.ps1.backup" -Force
    Write-Host "Original Start.ps1 backed up to Start.ps1.backup" -ForegroundColor Yellow
}

# Create the enhanced Start.ps1
@'
# ==============================================================================
# Axiom-Phoenix v4.0 - Enhanced Application Startup
# Beautiful splash screen and smooth initialization
# ==============================================================================

param(
    [string]$Theme = "Synthwave",
    [switch]$NoSplash,
    [switch]$Debug
)

# Set error action preference
$ErrorActionPreference = 'Stop'

# Function to display animated splash screen
function Show-SplashScreen {
    param([int]$Duration = 3000)
    
    Clear-Host
    $host.UI.RawUI.CursorSize = 0  # Hide cursor
    
    $width = $host.UI.RawUI.WindowSize.Width
    $height = $host.UI.RawUI.WindowSize.Height
    
    # ASCII Art Logo
    $logo = @"
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║      ___   _  _  _  ___  __  __     ___  _  _  ___  ___  _  _  _ ║
    ║     / _ \ | \/ || |/ _ \|  \/  |   | _ \| || |/ _ \| __|| \| || |║
    ║    | |_| | >  < | | (_) | |\/| |   |  _/| __ | (_) | _| | .  || |║
    ║    |_| |_|/_/\_\|_|\___/|_|  |_|   |_|  |_||_|\___/|___||_|\_||_|║
    ║                                                                   ║
    ║                        v4.0 ENHANCED EDITION                      ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
"@
    
    $tagline = "The Future of Terminal User Interfaces"
    $credits = "Powered by PowerShell 7+ | Built with ❤️"
    
    # Calculate positions
    $logoLines = $logo -split "`n"
    $logoWidth = ($logoLines | ForEach-Object { $_.Length } | Measure-Object -Maximum).Maximum
    $startX = [Math]::Max(0, [Math]::Floor(($width - $logoWidth) / 2))
    $startY = [Math]::Max(0, [Math]::Floor(($height - $logoLines.Count - 4) / 2))
    
    # Synthwave colors for animation
    $colors = @(
        [ConsoleColor]::Magenta,
        [ConsoleColor]::Cyan,
        [ConsoleColor]::Yellow,
        [ConsoleColor]::Green,
        [ConsoleColor]::Blue
    )
    
    # Animate logo appearance
    $steps = 20
    $stepDelay = $Duration / $steps
    
    for ($i = 0; $i -lt $steps; $i++) {
        $colorIndex = $i % $colors.Count
        $host.UI.RawUI.ForegroundColor = $colors[$colorIndex]
        
        # Clear and redraw
        Clear-Host
        
        # Draw logo with fade-in effect
        $y = $startY
        foreach ($line in $logoLines) {
            $host.UI.RawUI.CursorPosition = [System.Management.Automation.Host.Coordinates]::new($startX, $y)
            if ($i -ge $steps / 2 -or $y -eq $startY -or $y -eq ($startY + $logoLines.Count - 1)) {
                Write-Host $line -NoNewline
            }
            $y++
        }
        
        # Draw tagline
        if ($i -ge $steps * 0.6) {
            $taglineX = [Math]::Floor(($width - $tagline.Length) / 2)
            $host.UI.RawUI.CursorPosition = [System.Management.Automation.Host.Coordinates]::new($taglineX, $startY + $logoLines.Count + 1)
            Write-Host $tagline -ForegroundColor Cyan -NoNewline
        }
        
        # Draw credits
        if ($i -ge $steps * 0.8) {
            $creditsX = [Math]::Floor(($width - $credits.Length) / 2)
            $host.UI.RawUI.CursorPosition = [System.Management.Automation.Host.Coordinates]::new($creditsX, $startY + $logoLines.Count + 3)
            Write-Host $credits -ForegroundColor DarkGray -NoNewline
        }
        
        # Progress bar
        $progressY = $height - 3
        $progressWidth = 60
        $progressX = [Math]::Floor(($width - $progressWidth) / 2)
        $progress = [Math]::Floor(($i / $steps) * $progressWidth)
        
        $host.UI.RawUI.CursorPosition = [System.Management.Automation.Host.Coordinates]::new($progressX, $progressY)
        Write-Host "[" -NoNewline -ForegroundColor DarkGray
        Write-Host ("█" * $progress) -NoNewline -ForegroundColor Green
        Write-Host ("░" * ($progressWidth - $progress)) -NoNewline -ForegroundColor DarkGray
        Write-Host "]" -NoNewline -ForegroundColor DarkGray
        
        # Loading message
        $messages = @(
            "Initializing quantum cores...",
            "Loading neural matrices...",
            "Calibrating photon streams...",
            "Synchronizing time crystals...",
            "Establishing neural link..."
        )
        $messageIndex = [Math]::Floor(($i / $steps) * $messages.Count)
        $message = $messages[$messageIndex]
        $messageX = [Math]::Floor(($width - $message.Length) / 2)
        $host.UI.RawUI.CursorPosition = [System.Management.Automation.Host.Coordinates]::new($messageX, $progressY + 1)
        Write-Host $message -ForegroundColor Yellow
        
        Start-Sleep -Milliseconds $stepDelay
    }
    
    # Final pause
    Start-Sleep -Milliseconds 500
    
    # Reset
    $host.UI.RawUI.ForegroundColor = [ConsoleColor]::Gray
    $host.UI.RawUI.CursorSize = 25  # Restore cursor
    Clear-Host
}

# Main startup sequence
try {
    # Show splash screen unless disabled
    if (-not $NoSplash) {
        Show-SplashScreen -Duration 2000
    }
    
    Write-Host "Loading Axiom-Phoenix v4.0 Enhanced..." -ForegroundColor Cyan
    Write-Host ""
    
    # Verify PowerShell version
    if ($PSVersionTable.PSVersion.Major -lt 7) {
        Write-Host "ERROR: PowerShell 7.0 or higher is required!" -ForegroundColor Red
        Write-Host "Current version: $($PSVersionTable.PSVersion)" -ForegroundColor Yellow
        Write-Host "Download from: https://github.com/PowerShell/PowerShell" -ForegroundColor Cyan
        exit 1
    }
    
    # Get script directory
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    if ([string]::IsNullOrEmpty($scriptDir)) {
        $scriptDir = Get-Location
    }
    
    # Load framework files in order with progress indication
    $files = @(
        @{ File = "AllBaseClasses.ps1"; Description = "Core Framework" },
        @{ File = "AllModels.ps1"; Description = "Data Models" },
        @{ File = "AllComponents.ps1"; Description = "UI Components" },
        @{ File = "AllScreens.ps1"; Description = "Application Screens" },
        @{ File = "AllFunctions.ps1"; Description = "Utility Functions" },
        @{ File = "AllServices.ps1"; Description = "Business Services" },
        @{ File = "AllRuntime.ps1"; Description = "Runtime Engine" }
    )
    
    $totalFiles = $files.Count
    $currentFile = 0
    
    foreach ($fileInfo in $files) {
        $currentFile++
        $percent = [Math]::Floor(($currentFile / $totalFiles) * 100)
        
        Write-Host "[$percent%] " -NoNewline -ForegroundColor Green
        Write-Host "Loading $($fileInfo.Description)... " -NoNewline -ForegroundColor Gray
        
        $filePath = Join-Path $scriptDir $fileInfo.File
        if (Test-Path $filePath) {
            . $filePath
            Write-Host "✓" -ForegroundColor Green
        } else {
            Write-Host "✗" -ForegroundColor Red
            throw "File not found: $filePath"
        }
    }
    
    Write-Host ""
    Write-Host "All framework files loaded successfully!" -ForegroundColor Green
    Write-Host ""
    
    # Create service container
    Write-Host "Initializing services..." -ForegroundColor Cyan
    $container = [ServiceContainer]::new()
    
    # Register services with fancy names
    $services = @(
        @{ Type = "Logger"; Name = "Neural Logger" },
        @{ Type = "EventManager"; Name = "Quantum Event System" },
        @{ Type = "ThemeManager"; Name = "Photon Theme Engine" },
        @{ Type = "DataManager"; Name = "Data Matrix" },
        @{ Type = "ActionService"; Name = "Command Nexus" },
        @{ Type = "KeybindingService"; Name = "Neural Keybinds" },
        @{ Type = "NavigationService"; Name = "Dimensional Navigator" },
        @{ Type = "FocusManager"; Name = "Focus Controller" },
        @{ Type = "DialogManager"; Name = "Dialog Orchestrator" }
    )
    
    foreach ($service in $services) {
        Write-Host "  • Initializing $($service.Name)... " -NoNewline -ForegroundColor Gray
        
        $instance = switch ($service.Type) {
            "Logger" { [Logger]::new((Join-Path $env:TEMP "axiom-phoenix.log")) }
            "EventManager" { [EventManager]::new() }
            "ThemeManager" { [ThemeManager]::new() }
            "DataManager" { [DataManager]::new((Join-Path $env:TEMP "axiom-data.json")) }
            "ActionService" { [ActionService]::new() }
            "KeybindingService" { [KeybindingService]::new() }
            "NavigationService" { [NavigationService]::new() }
            "FocusManager" { [FocusManager]::new() }
            "DialogManager" { [DialogManager]::new() }
        }
        
        $container.Register($service.Type, $instance, "Singleton")
        Write-Host "✓" -ForegroundColor Green
    }
    
    # Set the selected theme
    $themeManager = $container.GetService("ThemeManager")
    if ($themeManager -and $Theme) {
        $themeManager.LoadTheme($Theme)
        Write-Host ""
        Write-Host "Theme '$Theme' activated!" -ForegroundColor Magenta
    }
    
    # Create sample data with enhanced items
    Write-Host ""
    Write-Host "Generating sample data..." -ForegroundColor Cyan
    $dataManager = $container.GetService("DataManager")
    
    # Enhanced sample tasks
    $sampleTasks = @(
        @{
            Title = "🚀 Launch Quantum Core Module"
            Description = "Initialize the quantum processing core for enhanced computational capabilities"
            Priority = "High"
            Progress = 75
        },
        @{
            Title = "🧬 Optimize Neural Networks"
            Description = "Fine-tune the AI neural network parameters for improved performance"
            Priority = "Medium"
            Progress = 45
        },
        @{
            Title = "🌊 Calibrate Wave Functions"
            Description = "Adjust quantum wave function parameters for stable operation"
            Priority = "High"
            Progress = 90
        },
        @{
            Title = "💎 Crystal Matrix Alignment"
            Description = "Align the photonic crystal matrix for optimal light transmission"
            Priority = "Low"
            Progress = 20
        },
        @{
            Title = "⚡ Energy Field Stabilization"
            Description = "Stabilize the plasma energy field generators"
            Priority = "Medium"
            Progress = 60
        }
    )
    
    foreach ($taskData in $sampleTasks) {
        $task = [PmcTask]::new()
        $task.Title = $taskData.Title
        $task.Description = $taskData.Description
        $task.Priority = [TaskPriority]::$($taskData.Priority)
        $task.SetProgress($taskData.Progress)
        $task.ProjectKey = "PHOENIX"
        $dataManager.AddTask($task) | Out-Null
    }
    
    Write-Host "Sample data created!" -ForegroundColor Green
    
    # Start application
    Write-Host ""
    Write-Host "════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host " AXIOM-PHOENIX v4.0 ENHANCED - READY TO LAUNCH! " -ForegroundColor Yellow
    Write-Host "════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Press any key to enter the matrix..." -ForegroundColor Green
    $null = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
    # Launch the application
    Clear-Host
    Start-AxiomPhoenix -Services $container
}
catch {
    Write-Host ""
    Write-Host "CRITICAL ERROR!" -ForegroundColor Red -BackgroundColor DarkRed
    Write-Host "Failed to load framework files!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Error Details:" -ForegroundColor Yellow
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Stack Trace:" -ForegroundColor Yellow
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    
    if ($Debug) {
        Write-Host ""
        Write-Host "Full Exception:" -ForegroundColor Yellow
        Write-Host $_ -ForegroundColor DarkGray
    }
    
    Write-Host ""
    Write-Host "Press any key to exit..." -ForegroundColor Gray
    $null = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}
'@ | Set-Content ".\Start.ps1" -Encoding UTF8

Write-Host "Enhanced Start.ps1 created successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "The application now features:" -ForegroundColor Cyan
Write-Host "  • Beautiful animated splash screen" -ForegroundColor White
Write-Host "  • Theme selection parameter" -ForegroundColor White
Write-Host "  • Enhanced sample data with emojis" -ForegroundColor White
Write-Host "  • Fancy service initialization messages" -ForegroundColor White
Write-Host ""
Write-Host "Run with: ./Start.ps1" -ForegroundColor Yellow
Write-Host "Or try:  ./Start.ps1 -Theme Aurora" -ForegroundColor Yellow
