# ==============================================================================
# Axiom-Phoenix v4.1 - New Task Screen (FIXED)
# Proper focus management following the definitive guide
# ==============================================================================

class NewTaskScreen : Screen {
    hidden [Panel] $_mainPanel
    hidden [Panel] $_formPanel
    hidden [TextBoxComponent] $_titleBox
    hidden [TextBoxComponent] $_descriptionBox
    hidden [ButtonComponent] $_saveButton
    hidden [ButtonComponent] $_cancelButton
    hidden [LabelComponent] $_priorityLabel
    hidden [LabelComponent] $_projectLabel
    hidden [LabelComponent] $_priorityValue
    hidden [LabelComponent] $_projectValue
    
    hidden [TaskPriority] $_selectedPriority = [TaskPriority]::Medium
    hidden [string] $_selectedProject = "General"
    
    # Services - get ALL in constructor per guide
    hidden $_navService
    hidden $_dataManager
    hidden $_focusManager
    
    NewTaskScreen([object]$serviceContainer) : base("NewTaskScreen", $serviceContainer) {
        $this.Title = " Create New Task "
        
        # Get ALL services in constructor - NEVER in methods
        $this._navService = $serviceContainer.GetService("NavigationService")
        $this._dataManager = $serviceContainer.GetService("DataManager")
        $this._focusManager = $serviceContainer.GetService("FocusManager")
        
        Write-Log -Level Debug -Message "NewTaskScreen: Constructor completed"
    }
    
    [void] Initialize() {
        Write-Log -Level Debug -Message "NewTaskScreen.Initialize: Starting"
        
        # Main panel (full screen)
        $this._mainPanel = [Panel]::new("NewTaskMainPanel")
        $this._mainPanel.X = 0
        $this._mainPanel.Y = 0
        $this._mainPanel.Width = $this.Width
        $this._mainPanel.Height = $this.Height
        $this._mainPanel.HasBorder = $false
        $this._mainPanel.BackgroundColor = Get-ThemeColor "panel.background" "#1e1e1e"
        $this.AddChild($this._mainPanel)
        
        # Form panel (centered)
        $formWidth = 60
        $formHeight = 20
        $this._formPanel = [Panel]::new("FormPanel")
        $this._formPanel.X = [Math]::Floor(($this.Width - $formWidth) / 2)
        $this._formPanel.Y = [Math]::Floor(($this.Height - $formHeight) / 2)
        $this._formPanel.Width = $formWidth
        $this._formPanel.Height = $formHeight
        $this._formPanel.Title = " Create New Task "
        $this._formPanel.BorderStyle = "Double"
        $this._formPanel.BorderColor = Get-ThemeColor "primary.accent" "#007acc"
        $this._formPanel.BackgroundColor = Get-ThemeColor "panel.background" "#1e1e1e"
        $this._mainPanel.AddChild($this._formPanel)
        
        # Build form fields
        $y = 2  # Start Y position
        
        # Title section
        $titleLabel = [LabelComponent]::new("TitleLabel")
        $titleLabel.Text = "Title:"
        $titleLabel.X = 2
        $titleLabel.Y = $y
        $titleLabel.ForegroundColor = Get-ThemeColor "label.foreground" "#d4d4d4"
        $this._formPanel.AddChild($titleLabel)
        
        $y += 1
        
        $this._titleBox = [TextBoxComponent]::new("TitleBox")
        $this._titleBox.X = 2
        $this._titleBox.Y = $y
        $this._titleBox.Width = $formWidth - 4
        $this._titleBox.Height = 3
        $this._titleBox.Placeholder = "Enter task title..."
        $this._titleBox.IsFocusable = $true
        $this._titleBox.AllowMultiline = $false
        $this._titleBox.MaxLength = 100
        $this._titleBox.BackgroundColor = Get-ThemeColor "input.background" "#2d2d2d"
        $this._titleBox.ForegroundColor = Get-ThemeColor "input.foreground" "#d4d4d4"
        $this._titleBox.BorderColor = Get-ThemeColor "input.border" "#404040"
        
        # Add missing focus handlers for TextBox
        $this._titleBox | Add-Member -MemberType ScriptMethod -Name OnFocus -Value {
            $this.BorderColor = Get-ThemeColor "primary.accent" "#007acc"
            $this.ShowCursor = $true
            $this.RequestRedraw()
        } -Force
        
        $this._titleBox | Add-Member -MemberType ScriptMethod -Name OnBlur -Value {
            $this.BorderColor = Get-ThemeColor "input.border" "#404040"
            $this.ShowCursor = $false
            $this.RequestRedraw()
        } -Force
        
        $this._formPanel.AddChild($this._titleBox)
        
        $y += 4
        
        # Description section
        $descLabel = [LabelComponent]::new("DescLabel")
        $descLabel.Text = "Description:"
        $descLabel.X = 2
        $descLabel.Y = $y
        $descLabel.ForegroundColor = Get-ThemeColor "label.foreground" "#d4d4d4"
        $this._formPanel.AddChild($descLabel)
        
        $y += 1
        
        $this._descriptionBox = [TextBoxComponent]::new("DescriptionBox")
        $this._descriptionBox.X = 2
        $this._descriptionBox.Y = $y
        $this._descriptionBox.Width = $formWidth - 4
        $this._descriptionBox.Height = 5
        $this._descriptionBox.Placeholder = "Enter task description (optional)..."
        $this._descriptionBox.IsFocusable = $true
        $this._descriptionBox.AllowMultiline = $true
        $this._descriptionBox.MaxLength = 500
        $this._descriptionBox.BackgroundColor = Get-ThemeColor "input.background" "#2d2d2d"
        $this._descriptionBox.ForegroundColor = Get-ThemeColor "input.foreground" "#d4d4d4"
        $this._descriptionBox.BorderColor = Get-ThemeColor "input.border" "#404040"
        
        # Add missing focus handlers for TextBox
        $this._descriptionBox | Add-Member -MemberType ScriptMethod -Name OnFocus -Value {
            $this.BorderColor = Get-ThemeColor "primary.accent" "#007acc"
            $this.ShowCursor = $true
            $this.RequestRedraw()
        } -Force
        
        $this._descriptionBox | Add-Member -MemberType ScriptMethod -Name OnBlur -Value {
            $this.BorderColor = Get-ThemeColor "input.border" "#404040"
            $this.ShowCursor = $false
            $this.RequestRedraw()
        } -Force
        
        $this._formPanel.AddChild($this._descriptionBox)
        
        $y += 6
        
        # Priority and Project row
        $this._priorityLabel = [LabelComponent]::new("PriorityLabel")
        $this._priorityLabel.Text = "Priority:"
        $this._priorityLabel.X = 2
        $this._priorityLabel.Y = $y
        $this._priorityLabel.ForegroundColor = Get-ThemeColor "label.foreground" "#d4d4d4"
        $this._formPanel.AddChild($this._priorityLabel)
        
        $this._priorityValue = [LabelComponent]::new("PriorityValue")
        $this._priorityValue.Text = "[$($this._selectedPriority)]"
        $this._priorityValue.X = 12
        $this._priorityValue.Y = $y
        $this._priorityValue.ForegroundColor = $this.GetPriorityColor($this._selectedPriority)
        $this._formPanel.AddChild($this._priorityValue)
        
        $this._projectLabel = [LabelComponent]::new("ProjectLabel")
        $this._projectLabel.Text = "Project:"
        $this._projectLabel.X = 30
        $this._projectLabel.Y = $y
        $this._projectLabel.ForegroundColor = Get-ThemeColor "label.foreground" "#d4d4d4"
        $this._formPanel.AddChild($this._projectLabel)
        
        $this._projectValue = [LabelComponent]::new("ProjectValue")
        $this._projectValue.Text = "[$($this._selectedProject)]"
        $this._projectValue.X = 39
        $this._projectValue.Y = $y
        $this._projectValue.ForegroundColor = Get-ThemeColor "primary.text" "#d4d4d4"
        $this._formPanel.AddChild($this._projectValue)
        
        $y += 2
        
        # Instructions
        $instrLabel = [LabelComponent]::new("InstrLabel")
        $instrLabel.Text = "Press 'P' to cycle priority | Tab to navigate"
        $instrLabel.X = 2
        $instrLabel.Y = $y
        $instrLabel.ForegroundColor = Get-ThemeColor "subtle" "#808080"
        $this._formPanel.AddChild($instrLabel)
        
        $y += 2
        
        # Buttons
        $buttonY = $formHeight - 3
        $this._saveButton = [ButtonComponent]::new("SaveButton")
        $this._saveButton.Text = " Save (S) "
        $this._saveButton.X = $formWidth - 25
        $this._saveButton.Y = $buttonY
        $this._saveButton.Width = 10
        $this._saveButton.Height = 1
        $this._saveButton.IsFocusable = $true
        $this._saveButton.BackgroundColor = Get-ThemeColor "button.primary" "#0078d4"
        $this._saveButton.ForegroundColor = Get-ThemeColor "button.foreground" "#ffffff"
        
        # Capture reference for closure
        $currentScreenRef = $this
        $this._saveButton.OnClick = {
            $currentScreenRef.SaveTask()
        }.GetNewClosure()
        $this._formPanel.AddChild($this._saveButton)
        
        $this._cancelButton = [ButtonComponent]::new("CancelButton")
        $this._cancelButton.Text = " Cancel (C) "
        $this._cancelButton.X = $formWidth - 14
        $this._cancelButton.Y = $buttonY
        $this._cancelButton.Width = 12
        $this._cancelButton.Height = 1
        $this._cancelButton.IsFocusable = $true
        $this._cancelButton.BackgroundColor = Get-ThemeColor "button.danger" "#d13438"
        $this._cancelButton.ForegroundColor = Get-ThemeColor "button.foreground" "#ffffff"
        
        $this._cancelButton.OnClick = {
            $currentScreenRef.Cancel()
        }.GetNewClosure()
        $this._formPanel.AddChild($this._cancelButton)
        
        Write-Log -Level Debug -Message "NewTaskScreen.Initialize: Completed"
    }
    
    [void] OnEnter() {
        Write-Log -Level Debug -Message "NewTaskScreen.OnEnter: Screen activated"
        
        # Reset form values
        $this._titleBox.Text = ""
        $this._descriptionBox.Text = ""
        $this._selectedPriority = [TaskPriority]::Medium
        $this._selectedProject = "General"
        
        # Update display
        $this._UpdatePriorityDisplay()
        
        # Set initial focus to title box using FocusManager
        if ($this._focusManager) {
            $this._focusManager.SetFocus($this._titleBox)
        }
        
        # MUST call base to set initial focus
        ([Screen]$this).OnEnter()
        
        $this.RequestRedraw()
    }
    
    hidden [string] GetPriorityColor([TaskPriority]$priority) {
        switch ($priority) {
            ([TaskPriority]::Low) { 
                return Get-ThemeColor "status.success" "#00d563" 
            }
            ([TaskPriority]::Medium) { 
                return Get-ThemeColor "status.warning" "#ffcc02" 
            }
            ([TaskPriority]::High) { 
                return Get-ThemeColor "status.error" "#d13438" 
            }
            default { 
                return Get-ThemeColor "label.foreground" "#d4d4d4" 
            }
        }
        # Explicit fallback return to satisfy PowerShell parser
        return Get-ThemeColor "label.foreground" "#d4d4d4"
    }
    
    hidden [void] _UpdatePriorityDisplay() {
        $this._priorityValue.Text = "[$($this._selectedPriority)]"
        $this._priorityValue.ForegroundColor = $this.GetPriorityColor($this._selectedPriority)
    }
    
    hidden [void] CyclePriority() {
        $priorities = @([TaskPriority]::Low, [TaskPriority]::Medium, [TaskPriority]::High)
        $currentIndex = [Array]::IndexOf($priorities, $this._selectedPriority)
        $this._selectedPriority = $priorities[($currentIndex + 1) % $priorities.Length]
        
        $this._UpdatePriorityDisplay()
        $this.RequestRedraw()
    }
    
    hidden [void] SaveTask() {
        Write-Log -Level Debug -Message "NewTaskScreen: Save task requested"
        
        # Validate
        if ([string]::IsNullOrWhiteSpace($this._titleBox.Text)) {
            Write-Log -Level Warning -Message "NewTaskScreen: Cannot save task without title"
            # Flash the title box border to indicate error
            $this._titleBox.BorderColor = Get-ThemeColor "status.error" "#d13438"
            $this.RequestRedraw()
            # Focus title box using FocusManager
            if ($this._focusManager) {
                $this._focusManager.SetFocus($this._titleBox)
            }
            return
        }
        
        # Create new task
        $task = [PmcTask]::new($this._titleBox.Text.Trim())
        $task.Description = $this._descriptionBox.Text.Trim()
        $task.Priority = $this._selectedPriority
        $task.ProjectKey = $this._selectedProject
        
        # Save via DataManager
        if ($this._dataManager) {
            $this._dataManager.AddTask($task)
            
            Write-Log -Level Info -Message "NewTaskScreen: Created task '$($task.Title)'"
            
            # Navigate back
            if ($this._navService -and $this._navService.CanGoBack()) {
                $this._navService.GoBack()
            }
        }
    }
    
    hidden [void] Cancel() {
        Write-Log -Level Debug -Message "NewTaskScreen: Cancelled"
        if ($this._navService -and $this._navService.CanGoBack()) {
            $this._navService.GoBack()
        }
    }
    
    # Input handling - EXACT pattern from guide
    [bool] HandleInput([System.ConsoleKeyInfo]$keyInfo) {
        if ($null -eq $keyInfo) {
            return $false
        }
        
        # Step 1: Get focused component CORRECTLY (METHOD not property!)
        $focused = $this.GetFocusedChild()
        
        # Step 2: Handle screen-level actions based on focused component
        switch ($keyInfo.Key) {
            ([ConsoleKey]::Enter) {
                # Different behavior based on what's focused
                if ($focused -eq $this._saveButton) {
                    $this.SaveTask()
                    return $true
                }
                elseif ($focused -eq $this._cancelButton) {
                    $this.Cancel()
                    return $true
                }
                # Don't handle Enter for text boxes - they handle themselves
            }
            ([ConsoleKey]::Escape) {
                # Screen-level: go back
                $this.Cancel()
                return $true
            }
        }
        
        # Step 3: Check for letter shortcuts
        switch ($keyInfo.KeyChar) {
            'p' { $this.CyclePriority(); return $true }
            'P' { $this.CyclePriority(); return $true }
            's' { 
                if ($keyInfo.Modifiers -eq [ConsoleModifiers]::None) {
                    $this.SaveTask(); return $true 
                }
            }
            'S' { 
                if ($keyInfo.Modifiers -eq [ConsoleModifiers]::None) {
                    $this.SaveTask(); return $true 
                }
            }
            'c' { 
                if ($keyInfo.Modifiers -eq [ConsoleModifiers]::None) {
                    $this.Cancel(); return $true 
                }
            }
            'C' { 
                if ($keyInfo.Modifiers -eq [ConsoleModifiers]::None) {
                    $this.Cancel(); return $true 
                }
            }
        }
        
        # Is the focused component handling it?
        if ($focused -and $focused.HandleInput($keyInfo)) {
            return $true
        }
        
        # Step 4: Let base handle Tab and route to components
        # DO NOT handle Tab yourself!
        return ([Screen]$this).HandleInput($keyInfo)
    }
}
