# Phase 2 Integration Demo
# Shows how all components work together

Write-Host "`n=== Phase 2 Integration Demo ===" -ForegroundColor Cyan
Write-Host "This demo shows the components working together`n" -ForegroundColor Yellow

# Load all dependencies
Write-Host "Loading modules..." -ForegroundColor Gray
. .\modules\core-utilities\core-utilities.psm1
. .\modules\models\models.psm1
. .\modules\event-system\event-system.psm1
. .\components\tui-primitives\tui-primitives.psm1
. .\modules\theme-manager\theme-manager.psm1
. .\components\ui-classes\ui-classes.psm1
. .\layout\panels-class\panels-class.psm1
. .\components\tui-components\tui-components.psm1

Write-Host "✓ Modules loaded" -ForegroundColor Green

# Create a demo panel
Write-Host "`nCreating UI demo..." -ForegroundColor Gray

$demoPanel = [Panel]::new("DemoPanel", "Component Demo")
$demoPanel.Width = 60
$demoPanel.Height = 20
$demoPanel.Initialize()

# Add title
$titleLabel = [LabelComponent]::new("PMC Terminal v3.2 - Component Showcase")
$titleLabel.X = 2
$titleLabel.Y = 1
$titleLabel.Width = 56
$titleLabel.TextAlign = "Center"
$titleLabel.Style = @{ FG = "#00FF00"; Bold = $true }
$titleLabel.Initialize()
$demoPanel.AddChild($titleLabel)

# Add input components
$y = 3

$nameLabel = [LabelComponent]::new("Name:")
$nameLabel.X = 2
$nameLabel.Y = $y
$nameLabel.Initialize()
$demoPanel.AddChild($nameLabel)

$nameTextBox = [TextBoxComponent]::new("Enter your name...")
$nameTextBox.X = 10
$nameTextBox.Y = $y
$nameTextBox.Width = 30
$nameTextBox.Initialize()
$demoPanel.AddChild($nameTextBox)

$y += 4

# Add checkbox
$agreeCheckBox = [CheckBoxComponent]::new("I agree to the terms")
$agreeCheckBox.X = 2
$agreeCheckBox.Y = $y
$agreeCheckBox.Initialize()
$demoPanel.AddChild($agreeCheckBox)

$y += 2

# Add radio buttons
$option1Radio = [RadioButtonComponent]::new("Option 1", "DemoGroup")
$option1Radio.X = 2
$option1Radio.Y = $y
$option1Radio.Initialize()
$demoPanel.AddChild($option1Radio)

$option2Radio = [RadioButtonComponent]::new("Option 2", "DemoGroup")
$option2Radio.X = 20
$option2Radio.Y = $y
$option2Radio.Initialize()
$demoPanel.AddChild($option2Radio)

$y += 3

# Add progress bar
$progressBar = [ProgressBarComponent]::new(100)
$progressBar.X = 2
$progressBar.Y = $y
$progressBar.Width = 40
$progressBar.Value = 65
$progressBar.Initialize()
$demoPanel.AddChild($progressBar)

$y += 4

# Add buttons
$submitButton = [ButtonComponent]::new("Submit", {
    Write-Host "`nForm submitted!" -ForegroundColor Green
})
$submitButton.X = 10
$submitButton.Y = $y
$submitButton.Initialize()
$demoPanel.AddChild($submitButton)

$cancelButton = [ButtonComponent]::new("Cancel", {
    Write-Host "`nCancelled!" -ForegroundColor Yellow
})
$cancelButton.X = 25
$cancelButton.Y = $y
$cancelButton.Initialize()
$demoPanel.AddChild($cancelButton)

# Render the panel
Write-Host "✓ UI created" -ForegroundColor Green
Write-Host "`nRendering UI..." -ForegroundColor Gray

$demoPanel.Render()

# Display buffer content as text (simplified visualization)
Write-Host "`n--- Rendered Output Preview ---" -ForegroundColor Cyan

# Create a simple text representation
$output = ""
for ($row = 0; $row -lt [Math]::Min(20, $demoPanel._private_buffer.Height); $row++) {
    $line = ""
    for ($col = 0; $col -lt [Math]::Min(60, $demoPanel._private_buffer.Width); $col++) {
        $cell = $demoPanel._private_buffer.GetCell($col, $row)
        if ($null -ne $cell) {
            $line += $cell.Char
        } else {
            $line += " "
        }
    }
    # Only print non-empty lines
    if ($line.Trim() -ne "") {
        Write-Host $line
    }
}

Write-Host "`n--- End Preview ---" -ForegroundColor Cyan

# Show component states
Write-Host "`nComponent States:" -ForegroundColor Yellow
Write-Host "  TextBox Text: '$($nameTextBox.Text)'" -ForegroundColor Gray
Write-Host "  CheckBox Checked: $($agreeCheckBox.Checked)" -ForegroundColor Gray
Write-Host "  Progress Value: $($progressBar.Value)%" -ForegroundColor Gray

# Event handling demo
Write-Host "`nEvent System Demo:" -ForegroundColor Yellow

$eventReceived = $false
Subscribe-Event -EventName "Demo.TestEvent" -Handler {
    param($data)
    Write-Host "  ✓ Event received: $($data.Message)" -ForegroundColor Green
    $script:eventReceived = $true
} -Source "DemoHandler"

Write-Host "  Publishing test event..." -ForegroundColor Gray
Publish-Event -EventName "Demo.TestEvent" -Data @{Message="Hello from Phase 2!"}

if ($eventReceived) {
    Write-Host "  ✓ Event system working correctly" -ForegroundColor Green
}

# Cleanup
$demoPanel.Dispose()

Write-Host "`n✅ Integration demo complete!" -ForegroundColor Green
Write-Host "All Phase 2 components are working together successfully." -ForegroundColor Green