# ==============================================================================
# Keybinding Service v3.2 - Global Keyboard Shortcut Management
# ==============================================================================

class KeyBinding {
    [ConsoleKey] $Key
    [ConsoleModifiers] $Modifiers
    [string] $Description
    [scriptblock] $Action
    [string] $Context = "Global"
    [bool] $Enabled = $true
    
    KeyBinding([ConsoleKey]$key, [scriptblock]$action) {
        $this.Key = $key
        $this.Action = $action
        $this.Modifiers = [ConsoleModifiers]::None
    }
    
    KeyBinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers, [scriptblock]$action) {
        $this.Key = $key
        $this.Modifiers = $modifiers
        $this.Action = $action
    }
    
    [bool] Matches([ConsoleKeyInfo]$keyInfo) {
        return $this.Enabled -and 
               $keyInfo.Key -eq $this.Key -and 
               $keyInfo.Modifiers -eq $this.Modifiers
    }
    
    [string] ToString() {
        $parts = @()
        if ($this.Modifiers -band [ConsoleModifiers]::Control) { $parts += "Ctrl" }
        if ($this.Modifiers -band [ConsoleModifiers]::Alt) { $parts += "Alt" }
        if ($this.Modifiers -band [ConsoleModifiers]::Shift) { $parts += "Shift" }
        $parts += $this.Key.ToString()
        return $parts -join "+"
    }
}

class KeybindingService {
    hidden [System.Collections.Generic.List[KeyBinding]] $_bindings
    hidden [hashtable] $_contextStates = @{}
    hidden [string] $_activeContext = "Global"
    
    KeybindingService() {
        $this._bindings = [System.Collections.Generic.List[KeyBinding]]::new()
        $this.RegisterDefaultBindings()
        Write-Log -Level Info -Message "KeybindingService initialized"
    }
    
    hidden [void] RegisterDefaultBindings() {
        # Global navigation
        $this.RegisterKeybinding([ConsoleKey]::Escape, {
            Publish-Event -EventName "Navigation.Back" -Data $null
        }, "Go back", "Global")
        
        $this.RegisterKeybinding([ConsoleKey]::Q, [ConsoleModifiers]::Control, {
            Publish-Event -EventName "Application.Quit" -Data $null
        }, "Quit application", "Global")
        
        $this.RegisterKeybinding([ConsoleKey]::S, [ConsoleModifiers]::Control, {
            Publish-Event -EventName "Data.Save" -Data $null
        }, "Save data", "Global")
        
        $this.RegisterKeybinding([ConsoleKey]::R, [ConsoleModifiers]::Control, {
            Publish-Event -EventName "Screen.Refresh" -Data $null
        }, "Refresh screen", "Global")
        
        # Navigation between components
        $this.RegisterKeybinding([ConsoleKey]::Tab, {
            Publish-Event -EventName "Focus.Next" -Data $null
        }, "Next component", "Global")
        
        $this.RegisterKeybinding([ConsoleKey]::Tab, [ConsoleModifiers]::Shift, {
            Publish-Event -EventName "Focus.Previous" -Data $null
        }, "Previous component", "Global")
        
        # Help
        $this.RegisterKeybinding([ConsoleKey]::F1, {
            Publish-Event -EventName "Help.Show" -Data $null
        }, "Show help", "Global")
        
        Write-Log -Level Info -Message "Registered default keybindings"
    }
    
    [void] RegisterKeybinding([ConsoleKey]$key, [scriptblock]$action, [string]$description) {
        $this.RegisterKeybinding($key, [ConsoleModifiers]::None, $action, $description, "Global")
    }
    
    [void] RegisterKeybinding([ConsoleKey]$key, [scriptblock]$action, [string]$description, [string]$context) {
        $this.RegisterKeybinding($key, [ConsoleModifiers]::None, $action, $description, $context)
    }
    
    [void] RegisterKeybinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers, [scriptblock]$action, [string]$description) {
        $this.RegisterKeybinding($key, $modifiers, $action, $description, "Global")
    }
    
    [void] RegisterKeybinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers, [scriptblock]$action, [string]$description, [string]$context) {
        # Check for existing binding
        $existing = $this._bindings | Where-Object {
            $_.Key -eq $key -and 
            $_.Modifiers -eq $modifiers -and 
            $_.Context -eq $context
        }
        
        if ($existing) {
            # Update existing
            $existing.Action = $action
            $existing.Description = $description
            Write-Log -Level Info -Message "Updated keybinding: $($existing.ToString()) in context '$context'"
        } else {
            # Add new
            $binding = [KeyBinding]::new($key, $modifiers, $action)
            $binding.Description = $description
            $binding.Context = $context
            $this._bindings.Add($binding)
            Write-Log -Level Info -Message "Registered keybinding: $($binding.ToString()) in context '$context'"
        }
    }
    
    [void] UnregisterKeybinding([ConsoleKey]$key) {
        $this.UnregisterKeybinding($key, [ConsoleModifiers]::None, "Global")
    }
    
    [void] UnregisterKeybinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers) {
        $this.UnregisterKeybinding($key, $modifiers, "Global")
    }
    
    [void] UnregisterKeybinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers, [string]$context) {
        $toRemove = $this._bindings | Where-Object {
            $_.Key -eq $key -and 
            $_.Modifiers -eq $modifiers -and 
            $_.Context -eq $context
        }
        
        foreach ($binding in $toRemove) {
            $this._bindings.Remove($binding) | Out-Null
            Write-Log -Level Info -Message "Unregistered keybinding: $($binding.ToString()) from context '$context'"
        }
    }
    
    [bool] HandleKeyPress([ConsoleKeyInfo]$keyInfo) {
        # First check context-specific bindings
        $contextBindings = $this._bindings | Where-Object {
            $_.Context -eq $this._activeContext -and $_.Matches($keyInfo)
        }
        
        if ($contextBindings) {
            $binding = $contextBindings | Select-Object -First 1
            try {
                Write-Log -Level Debug -Message "Executing keybinding: $($binding.ToString()) in context '$($this._activeContext)'"
                & $binding.Action
                return $true
            } catch {
                Write-Log -Level Error -Message "Failed to execute keybinding: $_"
            }
        }
        
        # Then check global bindings
        if ($this._activeContext -ne "Global") {
            $globalBindings = $this._bindings | Where-Object {
                $_.Context -eq "Global" -and $_.Matches($keyInfo)
            }
            
            if ($globalBindings) {
                $binding = $globalBindings | Select-Object -First 1
                try {
                    Write-Log -Level Debug -Message "Executing global keybinding: $($binding.ToString())"
                    & $binding.Action
                    return $true
                } catch {
                    Write-Log -Level Error -Message "Failed to execute keybinding: $_"
                }
            }
        }
        
        return $false
    }
    
    [void] SetContext([string]$context) {
        if ([string]::IsNullOrEmpty($context)) { $context = "Global" }
        $this._activeContext = $context
        Write-Log -Level Debug -Message "Keybinding context set to: $context"
        Publish-Event -EventName "Keybinding.ContextChanged" -Data @{Context=$context}
    }
    
    [string] GetContext() {
        return $this._activeContext
    }
    
    [void] EnableContext([string]$context) {
        $this._contextStates[$context] = $true
        Write-Log -Level Debug -Message "Enabled keybinding context: $context"
    }
    
    [void] DisableContext([string]$context) {
        $this._contextStates[$context] = $false
        Write-Log -Level Debug -Message "Disabled keybinding context: $context"
    }
    
    [bool] IsContextEnabled([string]$context) {
        if (-not $this._contextStates.ContainsKey($context)) {
            return $true  # Contexts are enabled by default
        }
        return $this._contextStates[$context]
    }
    
    [KeyBinding[]] GetKeybindings() {
        return $this._bindings.ToArray()
    }
    
    [KeyBinding[]] GetKeybindingsByContext([string]$context) {
        return $this._bindings | Where-Object { $_.Context -eq $context }
    }
    
    [hashtable[]] GetKeybindingHelp() {
        $help = @()
        
        # Group by context
        $contexts = $this._bindings | Group-Object -Property Context
        
        foreach ($contextGroup in $contexts) {
            foreach ($binding in $contextGroup.Group) {
                if ($binding.Enabled) {
                    $help += @{
                        Key = $binding.ToString()
                        Description = $binding.Description
                        Context = $binding.Context
                    }
                }
            }
        }
        
        return $help | Sort-Object Context, Key
    }
    
    [void] EnableKeybinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers, [string]$context) {
        $binding = $this._bindings | Where-Object {
            $_.Key -eq $key -and 
            $_.Modifiers -eq $modifiers -and 
            $_.Context -eq $context
        } | Select-Object -First 1
        
        if ($binding) {
            $binding.Enabled = $true
        }
    }
    
    [void] DisableKeybinding([ConsoleKey]$key, [ConsoleModifiers]$modifiers, [string]$context) {
        $binding = $this._bindings | Where-Object {
            $_.Key -eq $key -and 
            $_.Modifiers -eq $modifiers -and 
            $_.Context -eq $context
        } | Select-Object -First 1
        
        if ($binding) {
            $binding.Enabled = $false
        }
    }
}