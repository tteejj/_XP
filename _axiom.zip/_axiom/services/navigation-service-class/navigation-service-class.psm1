# ==============================================================================
# Navigation Service v3.2 - Screen Routing and Management
# ==============================================================================

class NavigationService {
    hidden [System.Collections.Generic.Stack[Screen]] $_screenStack
    hidden [hashtable] $_routes = @{}
    hidden [Screen] $_currentScreen = $null
    hidden [TuiEngine] $_engine = $null
    hidden [DataManager] $_dataManager = $null
    hidden [ThemeEngine] $_themeEngine = $null
    
    NavigationService() {
        $this._screenStack = [System.Collections.Generic.Stack[Screen]]::new()
        Write-Log -Level Info -Message "NavigationService initialized"
    }
    
    [void] InjectDependencies([TuiEngine]$engine, [DataManager]$dataManager, [ThemeEngine]$themeEngine) {
        $this._engine = $engine
        $this._dataManager = $dataManager
        $this._themeEngine = $themeEngine
        Write-Log -Level Info -Message "Dependencies injected into NavigationService"
    }
    
    [void] RegisterRoute([string]$route, [type]$screenType) {
        if ([string]::IsNullOrEmpty($route)) {
            throw [System.ArgumentException]::new("Route cannot be empty")
        }
        
        if (-not $screenType.IsSubclassOf([Screen])) {
            throw [System.ArgumentException]::new("Screen type must inherit from Screen class")
        }
        
        $this._routes[$route] = $screenType
        Write-Log -Level Info -Message "Registered route '$route' -> $($screenType.Name)"
    }
    
    [void] NavigateTo([string]$route) {
        NavigateTo($route, @{})
    }
    
    [void] NavigateTo([string]$route, [hashtable]$parameters) {
        if (-not $this._routes.ContainsKey($route)) {
            throw [System.InvalidOperationException]::new("Route '$route' not registered")
        }
        
        try {
            # Deactivate current screen
            if ($null -ne $this._currentScreen) {
                $this._currentScreen.OnScreenDeactivated()
                $this._currentScreen.Dispose()
            }
            
            # Create new screen instance
            $screenType = $this._routes[$route]
            $newScreen = $screenType::new()
            $newScreen.Route = $route
            
            # Inject services
            $newScreen.InjectServices($this, $this._dataManager, $this._themeEngine)
            
            # Initialize screen with engine dimensions
            if ($null -ne $this._engine) {
                $newScreen.Width = $this._engine.ScreenWidth
                $newScreen.Height = $this._engine.ScreenHeight
            }
            
            $newScreen.Initialize()
            
            # Push to stack and activate
            $this._screenStack.Push($newScreen)
            $this._currentScreen = $newScreen
            $this._currentScreen.OnScreenActivated()
            
            # Update engine's current screen
            if ($null -ne $this._engine) {
                $this._engine.SetCurrentScreen($newScreen)
            }
            
            Write-Log -Level Info -Message "Navigated to route: $route"
            Publish-Event -EventName "Navigation.Changed" -Data @{Route=$route;Screen=$newScreen}
            
        } catch {
            Write-Log -Level Error -Message "Failed to navigate to route '$route': $_"
            throw
        }
    }
    
    [void] GoBack() {
        if ($this._screenStack.Count -le 1) {
            Write-Log -Level Warning -Message "Cannot go back - no previous screen"
            return
        }
        
        try {
            # Remove current screen
            $oldScreen = $this._screenStack.Pop()
            $oldScreen.OnScreenDeactivated()
            $oldScreen.Dispose()
            
            # Activate previous screen
            $this._currentScreen = $this._screenStack.Peek()
            $this._currentScreen.OnScreenActivated()
            
            # Update engine
            if ($null -ne $this._engine) {
                $this._engine.SetCurrentScreen($this._currentScreen)
            }
            
            Write-Log -Level Info -Message "Navigated back to: $($this._currentScreen.Route)"
            Publish-Event -EventName "Navigation.Back" -Data @{Screen=$this._currentScreen}
            
        } catch {
            Write-Log -Level Error -Message "Failed to go back: $_"
            throw
        }
    }
    
    [Screen] GetCurrentScreen() {
        return $this._currentScreen
    }
    
    [string] GetCurrentRoute() {
        return if ($null -ne $this._currentScreen) { $this._currentScreen.Route } else { $null }
    }
    
    [bool] CanGoBack() {
        return $this._screenStack.Count -gt 1
    }
    
    [void] ClearHistory() {
        while ($this._screenStack.Count -gt 1) {
            $screen = $this._screenStack.Pop()
            $screen.Dispose()
        }
        Write-Log -Level Info -Message "Navigation history cleared"
    }
}

# Screen Registry for easier management
class ScreenRegistry {
    hidden static [hashtable] $_registry = @{}
    
    static [void] Register([string]$name, [type]$screenType) {
        if (-not $screenType.IsSubclassOf([Screen])) {
            throw [System.ArgumentException]::new("Type must inherit from Screen")
        }
        [ScreenRegistry]::_registry[$name] = $screenType
        Write-Log -Level Info -Message "Registered screen: $name"
    }
    
    static [type] Get([string]$name) {
        if (-not [ScreenRegistry]::_registry.ContainsKey($name)) {
            throw [System.InvalidOperationException]::new("Screen '$name' not registered")
        }
        return [ScreenRegistry]::_registry[$name]
    }
    
    static [string[]] GetRegisteredScreens() {
        return [ScreenRegistry]::_registry.Keys
    }
    
    static [void] Clear() {
        [ScreenRegistry]::_registry.Clear()
    }
}