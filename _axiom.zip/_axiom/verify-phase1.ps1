# Phase 1 Verification Script
# Tests that all core foundation modules are working correctly

Write-Host "`n=== Phase 1 Verification Script ===" -ForegroundColor Cyan
Write-Host "Testing core foundation modules...`n" -ForegroundColor Yellow

$testResults = @()

# Test 1: Core Utilities
Write-Host "Test 1: Core Utilities Module" -ForegroundColor White
try {
     .\modules\core-utilities\core-utilities.psm1
    Write-Log -Level Info -Message "Core utilities test successful"
    $testResults += @{Test="Core Utilities"; Result="PASS"; Details="Logging functions work"}
} catch {
    $testResults += @{Test="Core Utilities"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 2: Models
Write-Host "`nTest 2: Models Module" -ForegroundColor White
try {
     .\modules\models\models.psm1
    $task = [PmcTask]::new("Test Task", "Test Description", [TaskPriority]::High, "TEST")
    if ($task.Title -eq "Test Task" -and $task.Priority -eq [TaskPriority]::High) {
        Write-Host "✓ PmcTask created successfully" -ForegroundColor Green
        $testResults += @{Test="Models"; Result="PASS"; Details="Task and Project classes work"}
    } else {
        throw "Task properties not set correctly"
    }
} catch {
    $testResults += @{Test="Models"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 3: Event System
Write-Host "`nTest 3: Event System Module" -ForegroundColor White
try {
     .\modules\event-system\event-system.psm1
    $testValue = $null
    $handlerId = Subscribe-Event -EventName "Test.Event" -Handler { param($data) $script:testValue = $data } -Source "Test"
    Publish-Event -EventName "Test.Event" -Data "TestData"
    if ($testValue -eq "TestData") {
        Write-Host "✓ Event system pub/sub works" -ForegroundColor Green
        Unsubscribe-Event -HandlerId $handlerId
        $testResults += @{Test="Event System"; Result="PASS"; Details="Pub/sub mechanism works"}
    } else {
        throw "Event data not received"
    }
} catch {
    $testResults += @{Test="Event System"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 4: TUI Primitives
Write-Host "`nTest 4: TUI Primitives Module" -ForegroundColor White
try {
     .\components\tui-primitives\tui-primitives.psm1
    
    # Test TuiCell
    $cell = [TuiCell]::new()
    $cell.Char = 'X'
    $cell.ForegroundColor = "#FF0000"
    
    # Test TuiBuffer
    $buffer = [TuiBuffer]::new(10, 5, "TestBuffer")
    $buffer.SetCell(0, 0, $cell)
    
    # Test GetSubBuffer
    $subBuffer = $buffer.GetSubBuffer(0, 0, 5, 3)
    if ($null -ne $subBuffer -and $subBuffer.Width -eq 5 -and $subBuffer.Height -eq 3) {
        Write-Host "✓ TuiBuffer with GetSubBuffer works" -ForegroundColor Green
        $testResults += @{Test="TUI Primitives"; Result="PASS"; Details="TuiCell, TuiBuffer, and GetSubBuffer work"}
    } else {
        throw "GetSubBuffer failed"
    }
} catch {
    $testResults += @{Test="TUI Primitives"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 5: Theme Manager
Write-Host "`nTest 5: Theme Manager Module" -ForegroundColor White
try {
     .\modules\theme-manager\theme-manager.psm1
    $engine = Initialize-ThemeEngine
    $style = $engine.GetStyle("test.path")
    if ($style.FG -eq "#C0C0C0" -and $null -eq $style.BG) {
        Write-Host "✓ Theme engine stub works" -ForegroundColor Green
        $testResults += @{Test="Theme Manager"; Result="PASS"; Details="Stub returns default styles"}
    } else {
        throw "Unexpected style values"
    }
} catch {
    $testResults += @{Test="Theme Manager"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 6: UI Classes
Write-Host "`nTest 6: UI Classes Module" -ForegroundColor White
try {
     .\components\ui-classes\ui-classes.psm1
    
    $element = [UIElement]::new()
    $element.Name = "TestElement"
    $element.Width = 20
    $element.Height = 10
    $element.Initialize()
    
    if ($null -ne $element._private_buffer -and $element._private_buffer.Width -eq 20) {
        Write-Host "✓ UIElement with buffer management works" -ForegroundColor Green
        $testResults += @{Test="UI Classes"; Result="PASS"; Details="UIElement hierarchy works"}
    } else {
        throw "UIElement buffer not initialized"
    }
} catch {
    $testResults += @{Test="UI Classes"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 7: Panel Classes
Write-Host "`nTest 7: Panel Classes Module" -ForegroundColor White
try {
     .\layout\panels-class\panels-class.psm1
    
    $scrollPanel = [ScrollablePanel]::new("TestScroll", "Test Panel")
    $scrollPanel.Width = 40
    $scrollPanel.Height = 20
    $scrollPanel.Initialize()
    $scrollPanel.SetContentSize(100, 50)
    
    if ($scrollPanel._contentWidth -eq 100 -and $scrollPanel._contentHeight -eq 50) {
        Write-Host "✓ ScrollablePanel works" -ForegroundColor Green
        $testResults += @{Test="Panel Classes"; Result="PASS"; Details="ScrollablePanel and layouts work"}
    } else {
        throw "ScrollablePanel content size not set"
    }
} catch {
    $testResults += @{Test="Panel Classes"; Result="FAIL"; Details=$_.Exception.Message}
}

# Summary
Write-Host "`n=== Test Summary ===" -ForegroundColor Cyan
$passCount = ($testResults | Where-Object { $_.Result -eq "PASS" }).Count
$totalCount = $testResults.Count

foreach ($result in $testResults) {
    $color = if ($result.Result -eq "PASS") { "Green" } else { "Red" }
    Write-Host "$($result.Test): $($result.Result)" -ForegroundColor $color
    if ($result.Result -eq "FAIL") {
        Write-Host "  Details: $($result.Details)" -ForegroundColor DarkRed
    }
}

Write-Host "`nTotal: $passCount/$totalCount tests passed" -ForegroundColor $(if ($passCount -eq $totalCount) { "Green" } else { "Yellow" })

if ($passCount -eq $totalCount) {
    Write-Host "`n✅ Phase 1 foundation is ready!" -ForegroundColor Green
    Write-Host "All core modules are working correctly." -ForegroundColor Green
} else {
    Write-Host "`n⚠️  Some tests failed. Please review the errors above." -ForegroundColor Yellow
}