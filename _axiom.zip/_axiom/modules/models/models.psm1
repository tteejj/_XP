# modules/models/models.psm1
enum TaskPriority { Low; Medium; High; Critical }
enum TaskStatus { Pending; InProgress; Completed; Cancelled }

class PmcTask {
    [string]$Id = [Guid]::NewGuid().ToString(); [string]$Title; [string]$Description; [TaskPriority]$Priority = [TaskPriority]::Medium; [TaskStatus]$Status = [TaskStatus]::Pending; [string]$ProjectKey; [datetime]$CreatedAt = [datetime]::Now; [datetime]$UpdatedAt = [datetime]::Now; [datetime]$DueDate; [bool]$Completed = $false
    PmcTask([string]$title, [string]$description, [TaskPriority]$priority, [string]$projectKey) { $this.Title = $title; $this.Description = $description; $this.Priority = $priority; $this.ProjectKey = $projectKey }
    [hashtable] ToLegacyFormat() { return @{ Id = $this.Id; Title = $this.Title; Description = $this.Description; Priority = $this.Priority.ToString(); Status = $this.Status.ToString(); ProjectKey = $this.ProjectKey; CreatedAt = $this.CreatedAt.ToString("o"); UpdatedAt = $this.UpdatedAt.ToString("o"); DueDate = if($this.DueDate) {$this.DueDate.ToString("o")} else {$null}; Completed = $this.Completed } }
    static [PmcTask] FromLegacyFormat([hashtable]$data) { $task = [PmcTask]::new($data.Title, $data.Description, [TaskPriority]::$($data.Priority), $data.ProjectKey); $task.Id = $data.Id; $task.Status = [TaskStatus]::$($data.Status); $task.CreatedAt = [datetime]::Parse($data.CreatedAt); $task.UpdatedAt = [datetime]::Parse($data.UpdatedAt); if ($data.DueDate) { $task.DueDate = [datetime]::Parse($data.DueDate) }; $task.Completed = $data.Completed; return $task }
}

class PmcProject {
    [string]$Key; [string]$Name; [string]$Description
    PmcProject([string]$key, [string]$name) { $this.Key = $key; $this.Name = $name }
    [hashtable] ToLegacyFormat() { return @{ Key = $this.Key; Name = $this.Name; Description = $this.Description } }
    static [PmcProject] FromLegacyFormat([hashtable]$data) { $project = [PmcProject]::new($data.Key, $data.Name); $project.Description = $data.Description; return $project }
}