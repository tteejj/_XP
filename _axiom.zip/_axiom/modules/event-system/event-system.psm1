# modules/event-system/event-system.psm1
$global:EventHandlers = @{}
$global:HandlerCounter = 0

function Subscribe-Event {
    param([string]$EventName, [scriptblock]$Handler, [string]$Source)
    $id = "handler_$($global:HandlerCounter++)"
    if (-not $global:EventHandlers.ContainsKey($EventName)) {
        $global:EventHandlers[$EventName] = [System.Collections.Concurrent.ConcurrentDictionary[string, object]]::new()
    }
    $global:EventHandlers[$EventName][$id] = @{Handler=$Handler; Source=$Source}
    return $id
}

function Publish-Event {
    param([string]$EventName, $Data)
    if ($global:EventHandlers.ContainsKey($EventName)) {
        foreach ($handlerId in $global:EventHandlers[$EventName].Keys) {
            try { & $global:EventHandlers[$EventName][$handlerId].Handler $Data } catch { Write-Log -Level Error -Message "Event handler ($($handlerId)) failed for event '$EventName': $_" }
        }
    }
}

function Unsubscribe-Event {
    param([string]$HandlerId)
    foreach ($eventName in $global:EventHandlers.Keys) {
        if ($global:EventHandlers[$eventName].ContainsKey($HandlerId)) {
            $global:EventHandlers[$eventName].TryRemove($HandlerId, [ref]$null) | Out-Null
        }
    }
}