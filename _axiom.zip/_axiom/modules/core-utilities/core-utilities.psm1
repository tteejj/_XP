# modules/core-utilities/core-utilities.psm1
function Write-Log {
    param([string]$Level, [string]$Message, $Data)
    # Minimal implementation for now. Can be expanded later to write to a file.
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [$Level] $Message"
}

function Invoke-WithErrorHandling {
    param([string]$Component, [string]$Context, [scriptblock]$ScriptBlock)
    try {
        & $ScriptBlock
    } catch {
        Write-Log -Level Error -Message "Critical error in component '$Component' during context '$Context'. Exception: $($_.Exception.Message)"
        # Re-throw to allow higher-level handlers (like the PanicHandler) to catch it.
        throw
    }
}