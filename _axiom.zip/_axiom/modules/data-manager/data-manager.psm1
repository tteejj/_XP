# ==============================================================================
# Data Manager v3.2 - Persistence and State Management
# ==============================================================================

class DataManager {
    hidden [string] $_dataPath
    hidden [hashtable] $_cache = @{
        Tasks = [System.Collections.Generic.List[PmcTask]]::new()
        Projects = [System.Collections.Generic.List[PmcProject]]::new()
    }
    hidden [bool] $_isDirty = $false
    hidden [System.Threading.Timer] $_autoSaveTimer = $null
    
    DataManager() {
        $this._dataPath = Join-Path $env:APPDATA "PMCTerminal\data.json"
        $this.Initialize()
    }
    
    DataManager([string]$dataPath) {
        $this._dataPath = $dataPath
        $this.Initialize()
    }
    
    hidden [void] Initialize() {
        # Ensure directory exists
        $dir = Split-Path $this._dataPath -Parent
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        
        # Load existing data
        $this.Load()
        
        # Setup auto-save timer (every 5 minutes)
        $callback = {
            param($state)
            if ($state._isDirty) {
                $state.Save()
            }
        }
        $this._autoSaveTimer = [System.Threading.Timer]::new($callback, $this, 300000, 300000)
        
        Write-Log -Level Info -Message "DataManager initialized with path: $($this._dataPath)"
    }
    
    [void] Load() {
        try {
            if (Test-Path $this._dataPath) {
                $json = Get-Content $this._dataPath -Raw
                $data = ConvertFrom-Json $json -AsHashtable
                
                # Load projects
                $this._cache.Projects.Clear()
                if ($data.ContainsKey('Projects')) {
                    foreach ($projData in $data.Projects) {
                        $project = [PmcProject]::FromLegacyFormat($projData)
                        $this._cache.Projects.Add($project)
                    }
                }
                
                # Load tasks
                $this._cache.Tasks.Clear()
                if ($data.ContainsKey('Tasks')) {
                    foreach ($taskData in $data.Tasks) {
                        $task = [PmcTask]::FromLegacyFormat($taskData)
                        $this._cache.Tasks.Add($task)
                    }
                }
                
                Write-Log -Level Info -Message "Loaded $($this._cache.Projects.Count) projects and $($this._cache.Tasks.Count) tasks"
            } else {
                # Create default data
                $this.CreateDefaultData()
            }
            
            $this._isDirty = $false
            Publish-Event -EventName "Data.Loaded" -Data @{Projects=$this._cache.Projects;Tasks=$this._cache.Tasks}
            
        } catch {
            Write-Log -Level Error -Message "Failed to load data: $_"
            $this.CreateDefaultData()
        }
    }
    
    [void] Save() {
        try {
            $data = @{
                Projects = $this._cache.Projects | ForEach-Object { $_.ToLegacyFormat() }
                Tasks = $this._cache.Tasks | ForEach-Object { $_.ToLegacyFormat() }
                Metadata = @{
                    Version = "3.2"
                    LastSaved = [datetime]::Now.ToString("o")
                }
            }
            
            $json = ConvertTo-Json $data -Depth 10
            Set-Content -Path $this._dataPath -Value $json -Encoding UTF8
            
            $this._isDirty = $false
            Write-Log -Level Info -Message "Data saved successfully"
            Publish-Event -EventName "Data.Saved" -Data @{Path=$this._dataPath}
            
        } catch {
            Write-Log -Level Error -Message "Failed to save data: $_"
            throw
        }
    }
    
    hidden [void] CreateDefaultData() {
        # Create default project
        $defaultProject = [PmcProject]::new("DEFAULT", "Default Project")
        $defaultProject.Description = "Tasks not assigned to a specific project"
        $this._cache.Projects.Add($defaultProject)
        
        # Create sample task
        $sampleTask = [PmcTask]::new(
            "Welcome to PMC Terminal",
            "This is a sample task. Press Enter to edit or create new tasks.",
            [TaskPriority]::Medium,
            "DEFAULT"
        )
        $this._cache.Tasks.Add($sampleTask)
        
        $this._isDirty = $true
        Write-Log -Level Info -Message "Created default data"
    }
    
    # Project Management
    [PmcProject[]] GetProjects() {
        return $this._cache.Projects.ToArray()
    }
    
    [PmcProject] GetProject([string]$key) {
        return $this._cache.Projects | Where-Object { $_.Key -eq $key } | Select-Object -First 1
    }
    
    [void] AddProject([PmcProject]$project) {
        if ($null -eq $project) { throw [System.ArgumentNullException]::new("project") }
        
        # Check for duplicate key
        if ($this.GetProject($project.Key)) {
            throw [System.InvalidOperationException]::new("Project with key '$($project.Key)' already exists")
        }
        
        $this._cache.Projects.Add($project)
        $this._isDirty = $true
        
        Write-Log -Level Info -Message "Added project: $($project.Name)"
        Publish-Event -EventName "Project.Added" -Data $project
    }
    
    [void] UpdateProject([PmcProject]$project) {
        if ($null -eq $project) { throw [System.ArgumentNullException]::new("project") }
        
        $existing = $this.GetProject($project.Key)
        if ($null -eq $existing) {
            throw [System.InvalidOperationException]::new("Project not found: $($project.Key)")
        }
        
        # Update properties
        $existing.Name = $project.Name
        $existing.Description = $project.Description
        
        $this._isDirty = $true
        Write-Log -Level Info -Message "Updated project: $($project.Name)"
        Publish-Event -EventName "Project.Updated" -Data $project
    }
    
    [void] RemoveProject([string]$key) {
        $project = $this.GetProject($key)
        if ($null -eq $project) { return }
        
        # Check for tasks assigned to this project
        $assignedTasks = $this._cache.Tasks | Where-Object { $_.ProjectKey -eq $key }
        if ($assignedTasks.Count -gt 0) {
            throw [System.InvalidOperationException]::new("Cannot remove project with assigned tasks")
        }
        
        $this._cache.Projects.Remove($project) | Out-Null
        $this._isDirty = $true
        
        Write-Log -Level Info -Message "Removed project: $($project.Name)"
        Publish-Event -EventName "Project.Removed" -Data $project
    }
    
    # Task Management
    [PmcTask[]] GetTasks() {
        return $this._cache.Tasks.ToArray()
    }
    
    [PmcTask[]] GetTasksByProject([string]$projectKey) {
        return $this._cache.Tasks | Where-Object { $_.ProjectKey -eq $projectKey }
    }
    
    [PmcTask[]] GetTasksByStatus([TaskStatus]$status) {
        return $this._cache.Tasks | Where-Object { $_.Status -eq $status }
    }
    
    [PmcTask] GetTask([string]$id) {
        return $this._cache.Tasks | Where-Object { $_.Id -eq $id } | Select-Object -First 1
    }
    
    [void] AddTask([PmcTask]$task) {
        if ($null -eq $task) { throw [System.ArgumentNullException]::new("task") }
        
        # Verify project exists
        if (-not $this.GetProject($task.ProjectKey)) {
            throw [System.InvalidOperationException]::new("Project not found: $($task.ProjectKey)")
        }
        
        $this._cache.Tasks.Add($task)
        $this._isDirty = $true
        
        Write-Log -Level Info -Message "Added task: $($task.Title)"
        Publish-Event -EventName "Task.Added" -Data $task
    }
    
    [void] UpdateTask([PmcTask]$task) {
        if ($null -eq $task) { throw [System.ArgumentNullException]::new("task") }
        
        $existing = $this.GetTask($task.Id)
        if ($null -eq $existing) {
            throw [System.InvalidOperationException]::new("Task not found: $($task.Id)")
        }
        
        # Update properties
        $existing.Title = $task.Title
        $existing.Description = $task.Description
        $existing.Priority = $task.Priority
        $existing.Status = $task.Status
        $existing.ProjectKey = $task.ProjectKey
        $existing.DueDate = $task.DueDate
        $existing.Completed = $task.Completed
        $existing.UpdatedAt = [datetime]::Now
        
        $this._isDirty = $true
        Write-Log -Level Info -Message "Updated task: $($task.Title)"
        Publish-Event -EventName "Task.Updated" -Data $task
    }
    
    [void] RemoveTask([string]$id) {
        $task = $this.GetTask($id)
        if ($null -eq $task) { return }
        
        $this._cache.Tasks.Remove($task) | Out-Null
        $this._isDirty = $true
        
        Write-Log -Level Info -Message "Removed task: $($task.Title)"
        Publish-Event -EventName "Task.Removed" -Data $task
    }
    
    [void] CompleteTask([string]$id) {
        $task = $this.GetTask($id)
        if ($null -eq $task) { return }
        
        $task.Status = [TaskStatus]::Completed
        $task.Completed = $true
        $task.UpdatedAt = [datetime]::Now
        
        $this._isDirty = $true
        Write-Log -Level Info -Message "Completed task: $($task.Title)"
        Publish-Event -EventName "Task.Completed" -Data $task
    }
    
    # Statistics
    [hashtable] GetStatistics() {
        $stats = @{
            TotalTasks = $this._cache.Tasks.Count
            TotalProjects = $this._cache.Projects.Count
            TasksByStatus = @{}
            TasksByPriority = @{}
            TasksByProject = @{}
        }
        
        foreach ($status in [Enum]::GetValues([TaskStatus])) {
            $stats.TasksByStatus[$status.ToString()] = ($this._cache.Tasks | Where-Object { $_.Status -eq $status }).Count
        }
        
        foreach ($priority in [Enum]::GetValues([TaskPriority])) {
            $stats.TasksByPriority[$priority.ToString()] = ($this._cache.Tasks | Where-Object { $_.Priority -eq $priority }).Count
        }
        
        foreach ($project in $this._cache.Projects) {
            $stats.TasksByProject[$project.Key] = ($this._cache.Tasks | Where-Object { $_.ProjectKey -eq $project.Key }).Count
        }
        
        return $stats
    }
    
    [void] Dispose() {
        if ($this._isDirty) {
            $this.Save()
        }
        
        if ($null -ne $this._autoSaveTimer) {
            $this._autoSaveTimer.Dispose()
            $this._autoSaveTimer = $null
        }
        
        Write-Log -Level Info -Message "DataManager disposed"
    }
}