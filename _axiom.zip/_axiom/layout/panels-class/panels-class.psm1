# ==============================================================================
# Panels v3.2 - Advanced Layout Container Classes
# ==============================================================================

# Note: The basic Panel class is defined in ui-classes.psm1
# This file extends with specialized panel types

class ScrollablePanel : Panel {
    hidden [int] $_scrollX = 0
    hidden [int] $_scrollY = 0
    hidden [int] $_contentWidth = 0
    hidden [int] $_contentHeight = 0
    hidden [TuiBuffer] $_contentBuffer = $null
    [bool] $ShowScrollbars = $true
    
    ScrollablePanel() : base() {}
    ScrollablePanel([string]$name, [string]$title) : base($name, $title) {}
    
    [void] OnInitialize() {
        ([Panel]$this).OnInitialize()
        $this._contentBuffer = [TuiBuffer]::new(100, 100, "$($this.Name).Content")
    }
    
    [void] OnDispose() {
        $this._contentBuffer = $null
        ([Panel]$this).OnDispose()
    }
    
    [void] SetContentSize([int]$width, [int]$height) {
        $this._contentWidth = [Math]::Max($width, $this.GetContentWidth())
        $this._contentHeight = [Math]::Max($height, $this.GetContentHeight())
        if ($null -ne $this._contentBuffer) {
            $this._contentBuffer.Resize($this._contentWidth, $this._contentHeight)
        }
    }
    
    [void] OnRender() {
        # First render the border
        ([Panel]$this).OnRender()
        
        if ($null -eq $this._contentBuffer -or $null -eq $this._private_buffer) { return }
        
        # Clear content buffer and let children render into it
        $this._contentBuffer.Clear()
        
        # Temporarily adjust child positions for scrolling
        foreach ($child in $this._children) {
            $originalX = $child.X
            $originalY = $child.Y
            $child.X -= $this._scrollX
            $child.Y -= $this._scrollY
            
            if ($child.Visible) {
                $child.Render()
                if ($null -ne $child._private_buffer) {
                    $this._contentBuffer.BlendBuffer($child._private_buffer, $child.X, $child.Y)
                }
            }
            
            # Restore original positions
            $child.X = $originalX
            $child.Y = $originalY
        }
        
        # Extract visible portion and blend into panel
        $visibleWidth = $this.GetContentWidth()
        $visibleHeight = $this.GetContentHeight()
        $visibleBuffer = $this._contentBuffer.GetSubBuffer($this._scrollX, $this._scrollY, $visibleWidth, $visibleHeight)
        
        if ($null -ne $visibleBuffer) {
            $this._private_buffer.BlendBuffer($visibleBuffer, $this.GetContentX(), $this.GetContentY())
        }
        
        # Render scrollbars if needed
        if ($this.ShowScrollbars) {
            $this.RenderScrollbars()
        }
    }
    
    hidden [void] RenderScrollbars() {
        if ($null -eq $this._private_buffer) { return }
        
        $contentX = $this.GetContentX()
        $contentY = $this.GetContentY()
        $visibleWidth = $this.GetContentWidth()
        $visibleHeight = $this.GetContentHeight()
        
        # Vertical scrollbar
        if ($this._contentHeight -gt $visibleHeight) {
            $scrollbarHeight = [Math]::Max(1, [int]($visibleHeight * $visibleHeight / $this._contentHeight))
            $scrollbarPos = [int]($this._scrollY * ($visibleHeight - $scrollbarHeight) / ($this._contentHeight - $visibleHeight))
            
            for ($y = 0; $y -lt $visibleHeight; $y++) {
                $char = if ($y -ge $scrollbarPos -and $y -lt ($scrollbarPos + $scrollbarHeight)) { '█' } else { '│' }
                Write-TuiText -B $this._private_buffer -X ($contentX + $visibleWidth) -Y ($contentY + $y) -T $char -S @{FG="#606060"}
            }
        }
        
        # Horizontal scrollbar
        if ($this._contentWidth -gt $visibleWidth) {
            $scrollbarWidth = [Math]::Max(1, [int]($visibleWidth * $visibleWidth / $this._contentWidth))
            $scrollbarPos = [int]($this._scrollX * ($visibleWidth - $scrollbarWidth) / ($this._contentWidth - $visibleWidth))
            
            for ($x = 0; $x -lt $visibleWidth; $x++) {
                $char = if ($x -ge $scrollbarPos -and $x -lt ($scrollbarPos + $scrollbarWidth)) { '█' } else { '─' }
                Write-TuiText -B $this._private_buffer -X ($contentX + $x) -Y ($contentY + $visibleHeight) -T $char -S @{FG="#606060"}
            }
        }
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        $handled = $false
        $visibleHeight = $this.GetContentHeight()
        $visibleWidth = $this.GetContentWidth()
        
        switch ($key.Key) {
            ([ConsoleKey]::UpArrow) {
                if ($key.Modifiers -band [ConsoleModifiers]::Control) {
                    $this.ScrollUp(5)
                    $handled = $true
                }
            }
            ([ConsoleKey]::DownArrow) {
                if ($key.Modifiers -band [ConsoleModifiers]::Control) {
                    $this.ScrollDown(5)
                    $handled = $true
                }
            }
            ([ConsoleKey]::PageUp) {
                $this.ScrollUp($visibleHeight - 1)
                $handled = $true
            }
            ([ConsoleKey]::PageDown) {
                $this.ScrollDown($visibleHeight - 1)
                $handled = $true
            }
            ([ConsoleKey]::Home) {
                if ($key.Modifiers -band [ConsoleModifiers]::Control) {
                    $this._scrollY = 0
                    $this.InvalidateRender()
                    $handled = $true
                }
            }
            ([ConsoleKey]::End) {
                if ($key.Modifiers -band [ConsoleModifiers]::Control) {
                    $this._scrollY = [Math]::Max(0, $this._contentHeight - $visibleHeight)
                    $this.InvalidateRender()
                    $handled = $true
                }
            }
        }
        
        if (-not $handled) {
            $handled = ([Panel]$this).OnHandleInput($key)
        }
        
        return $handled
    }
    
    [void] ScrollUp([int]$lines) {
        $this._scrollY = [Math]::Max(0, $this._scrollY - $lines)
        $this.InvalidateRender()
    }
    
    [void] ScrollDown([int]$lines) {
        $maxScroll = [Math]::Max(0, $this._contentHeight - $this.GetContentHeight())
        $this._scrollY = [Math]::Min($maxScroll, $this._scrollY + $lines)
        $this.InvalidateRender()
    }
    
    [void] ScrollLeft([int]$cols) {
        $this._scrollX = [Math]::Max(0, $this._scrollX - $cols)
        $this.InvalidateRender()
    }
    
    [void] ScrollRight([int]$cols) {
        $maxScroll = [Math]::Max(0, $this._contentWidth - $this.GetContentWidth())
        $this._scrollX = [Math]::Min($maxScroll, $this._scrollX + $cols)
        $this.InvalidateRender()
    }
    
    [void] ScrollToChild([UIElement]$child) {
        if ($null -eq $child -or -not $this._children.Contains($child)) { return }
        
        $visibleWidth = $this.GetContentWidth()
        $visibleHeight = $this.GetContentHeight()
        
        # Adjust scroll to make child visible
        if ($child.Y -lt $this._scrollY) {
            $this._scrollY = $child.Y
        } elseif (($child.Y + $child.Height) -gt ($this._scrollY + $visibleHeight)) {
            $this._scrollY = $child.Y + $child.Height - $visibleHeight
        }
        
        if ($child.X -lt $this._scrollX) {
            $this._scrollX = $child.X
        } elseif (($child.X + $child.Width) -gt ($this._scrollX + $visibleWidth)) {
            $this._scrollX = $child.X + $child.Width - $visibleWidth
        }
        
        $this.InvalidateRender()
    }
}

class GroupPanel : Panel {
    [bool] $Collapsed = $false
    hidden [int] $_expandedHeight = 0
    
    GroupPanel() : base() {}
    GroupPanel([string]$name, [string]$title) : base($name, $title) {}
    
    [void] Toggle() {
        if ($this.Collapsed) {
            $this.Expand()
        } else {
            $this.Collapse()
        }
    }
    
    [void] Collapse() {
        if ($this.Collapsed) { return }
        $this._expandedHeight = $this.Height
        $this.Height = 3  # Just title bar
        $this.Collapsed = $true
        $this.InvalidateRender()
    }
    
    [void] Expand() {
        if (-not $this.Collapsed) { return }
        $this.Height = $this._expandedHeight
        $this.Collapsed = $false
        $this.InvalidateRender()
    }
    
    [void] OnRender() {
        ([Panel]$this).OnRender()
        
        # Add collapse/expand indicator to title
        if (-not [string]::IsNullOrEmpty($this.Title) -and $this.ShowBorder) {
            $indicator = if ($this.Collapsed) { " [+]" } else { " [-]" }
            $titleWithIndicator = $this.Title + $indicator
            
            # Re-render title with indicator
            $titleStyle = @{
                FG = $this.Style.TitleFG ?? "#FFFFFF"
                BG = $this.Style.BG ?? $null
            }
            
            $maxTitleLength = $this.Width - 4
            if ($titleWithIndicator.Length -le $maxTitleLength) {
                $titleX = 2  # Start after border and space
                Write-TuiText -B $this._private_buffer -X $titleX -Y 0 -T $titleWithIndicator -S $titleStyle
            }
        }
        
        # Don't render children if collapsed
        if ($this.Collapsed) {
            foreach ($child in $this._children) {
                $child.Visible = $false
            }
        } else {
            foreach ($child in $this._children) {
                $child.Visible = $true
            }
        }
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        if ($key.Key -eq [ConsoleKey]::Enter -or $key.Key -eq [ConsoleKey]::Spacebar) {
            $this.Toggle()
            return $true
        }
        
        # Don't process child input if collapsed
        if ($this.Collapsed) {
            return $false
        }
        
        return ([Panel]$this).OnHandleInput($key)
    }
}

# Layout Managers
class VerticalStackLayout {
    [int] $Spacing = 1
    [bool] $ExpandChildren = $false
    
    [void] ArrangeChildren([Panel]$panel) {
        $children = $panel.GetChildren()
        if ($children.Count -eq 0) { return }
        
        $contentX = $panel.GetContentX()
        $contentY = $panel.GetContentY()
        $contentWidth = $panel.GetContentWidth()
        $contentHeight = $panel.GetContentHeight()
        
        $currentY = 0
        $visibleChildren = $children | Where-Object { $_.Visible }
        
        if ($this.ExpandChildren -and $visibleChildren.Count -gt 0) {
            # Distribute height evenly among visible children
            $totalSpacing = [Math]::Max(0, ($visibleChildren.Count - 1) * $this.Spacing)
            $childHeight = [Math]::Floor(($contentHeight - $totalSpacing) / $visibleChildren.Count)
            
            foreach ($child in $visibleChildren) {
                $child.X = 0
                $child.Y = $currentY
                $child.Width = $contentWidth
                $child.Height = $childHeight
                $child.Resize($child.Width, $child.Height)
                $currentY += $childHeight + $this.Spacing
            }
        } else {
            # Use natural height of children
            foreach ($child in $visibleChildren) {
                $child.X = 0
                $child.Y = $currentY
                if ($child.Width -eq 0 -or $child.Width -gt $contentWidth) {
                    $child.Width = $contentWidth
                }
                $currentY += $child.Height + $this.Spacing
            }
        }
    }
}

class HorizontalStackLayout {
    [int] $Spacing = 1
    [bool] $ExpandChildren = $false
    
    [void] ArrangeChildren([Panel]$panel) {
        $children = $panel.GetChildren()
        if ($children.Count -eq 0) { return }
        
        $contentX = $panel.GetContentX()
        $contentY = $panel.GetContentY()
        $contentWidth = $panel.GetContentWidth()
        $contentHeight = $panel.GetContentHeight()
        
        $currentX = 0
        $visibleChildren = $children | Where-Object { $_.Visible }
        
        if ($this.ExpandChildren -and $visibleChildren.Count -gt 0) {
            # Distribute width evenly among visible children
            $totalSpacing = [Math]::Max(0, ($visibleChildren.Count - 1) * $this.Spacing)
            $childWidth = [Math]::Floor(($contentWidth - $totalSpacing) / $visibleChildren.Count)
            
            foreach ($child in $visibleChildren) {
                $child.X = $currentX
                $child.Y = 0
                $child.Width = $childWidth
                $child.Height = $contentHeight
                $child.Resize($child.Width, $child.Height)
                $currentX += $childWidth + $this.Spacing
            }
        } else {
            # Use natural width of children
            foreach ($child in $visibleChildren) {
                $child.X = $currentX
                $child.Y = 0
                if ($child.Height -eq 0 -or $child.Height -gt $contentHeight) {
                    $child.Height = $contentHeight
                }
                $currentX += $child.Width + $this.Spacing
            }
        }
    }
}

class GridLayout {
    [int] $Columns = 2
    [int] $RowSpacing = 1
    [int] $ColumnSpacing = 1
    [bool] $ExpandChildren = $true
    
    [void] ArrangeChildren([Panel]$panel) {
        $children = $panel.GetChildren()
        if ($children.Count -eq 0) { return }
        
        $contentWidth = $panel.GetContentWidth()
        $contentHeight = $panel.GetContentHeight()
        
        $visibleChildren = $children | Where-Object { $_.Visible }
        if ($visibleChildren.Count -eq 0) { return }
        
        $rows = [Math]::Ceiling($visibleChildren.Count / $this.Columns)
        $totalColumnSpacing = [Math]::Max(0, ($this.Columns - 1) * $this.ColumnSpacing)
        $totalRowSpacing = [Math]::Max(0, ($rows - 1) * $this.RowSpacing)
        
        $cellWidth = [Math]::Floor(($contentWidth - $totalColumnSpacing) / $this.Columns)
        $cellHeight = [Math]::Floor(($contentHeight - $totalRowSpacing) / $rows)
        
        $index = 0
        foreach ($child in $visibleChildren) {
            $col = $index % $this.Columns
            $row = [Math]::Floor($index / $this.Columns)
            
            $child.X = $col * ($cellWidth + $this.ColumnSpacing)
            $child.Y = $row * ($cellHeight + $this.RowSpacing)
            
            if ($this.ExpandChildren) {
                $child.Width = $cellWidth
                $child.Height = $cellHeight
                $child.Resize($child.Width, $child.Height)
            }
            
            $index++
        }
    }
}