# ==============================================================================
# Dashboard Screen v3.2 - Main Application Screen
# ==============================================================================

class DashboardScreen : Screen {
    hidden [Panel] $_mainPanel
    hidden [Panel] $_statsPanel
    hidden [Panel] $_recentTasksPanel
    hidden [ButtonComponent] $_newTaskButton
    hidden [ButtonComponent] $_viewTasksButton
    hidden [LabelComponent] $_welcomeLabel
    
    DashboardScreen() : base("Dashboard", "/dashboard") {}
    
    [void] OnInitialize() {
        # Create main container
        $this._mainPanel = [Panel]::new("MainPanel", "PMC Terminal Dashboard")
        $this._mainPanel.X = 0
        $this._mainPanel.Y = 0
        $this._mainPanel.Width = $this.Width
        $this._mainPanel.Height = $this.Height
        $this._mainPanel.ShowBorder = $true
        $this._mainPanel.BorderStyle = "Double"
        $this.AddChild($this._mainPanel)
        
        # Welcome label
        $this._welcomeLabel = [LabelComponent]::new("Welcome to PMC Terminal v3.2")
        $this._welcomeLabel.X = 2
        $this._welcomeLabel.Y = 2
        $this._welcomeLabel.Width = $this._mainPanel.GetContentWidth() - 4
        $this._welcomeLabel.TextAlign = "Center"
        $this._welcomeLabel.Style = @{
            FG = "#00FF00"
            Bold = $true
        }
        $this._mainPanel.AddChild($this._welcomeLabel)
        
        # Statistics panel
        $this._statsPanel = [Panel]::new("StatsPanel", "Statistics")
        $this._statsPanel.X = 2
        $this._statsPanel.Y = 4
        $this._statsPanel.Width = [Math]::Floor($this._mainPanel.GetContentWidth() / 2) - 3
        $this._statsPanel.Height = 10
        $this._mainPanel.AddChild($this._statsPanel)
        
        # Recent tasks panel
        $this._recentTasksPanel = [Panel]::new("RecentPanel", "Recent Tasks")
        $this._recentTasksPanel.X = $this._statsPanel.X + $this._statsPanel.Width + 2
        $this._recentTasksPanel.Y = 4
        $this._recentTasksPanel.Width = $this._statsPanel.Width
        $this._recentTasksPanel.Height = 10
        $this._mainPanel.AddChild($this._recentTasksPanel)
        
        # Action buttons
        $buttonY = $this._statsPanel.Y + $this._statsPanel.Height + 2
        
        $this._newTaskButton = [ButtonComponent]::new("New Task", {
            Publish-Event -EventName "Navigation.Request" -Data @{Route="/tasks/new"}
        })
        $this._newTaskButton.X = 10
        $this._newTaskButton.Y = $buttonY
        $this._newTaskButton.IsDefault = $true
        $this._mainPanel.AddChild($this._newTaskButton)
        
        $this._viewTasksButton = [ButtonComponent]::new("View Tasks", {
            Publish-Event -EventName "Navigation.Request" -Data @{Route="/tasks"}
        })
        $this._viewTasksButton.X = $this._newTaskButton.X + $this._newTaskButton.Width + 4
        $this._viewTasksButton.Y = $buttonY
        $this._mainPanel.AddChild($this._viewTasksButton)
        
        # Subscribe to data events
        $this.SubscribeToEvent("Data.Loaded", { $this.RefreshData() })
        $this.SubscribeToEvent("Task.Added", { $this.RefreshData() })
        $this.SubscribeToEvent("Task.Updated", { $this.RefreshData() })
        $this.SubscribeToEvent("Task.Removed", { $this.RefreshData() })
        
        # Initial data load
        $this.RefreshData()
    }
    
    [void] OnScreenActivated() {
        # Set first button as focused
        $this._newTaskButton.SetFocus($true)
        $this.RefreshData()
    }
    
    [void] RefreshData() {
        if ($null -eq $this._dataManager) { return }
        
        # Get statistics
        $stats = $this._dataManager.GetStatistics()
        
        # Clear stats panel
        foreach ($child in $this._statsPanel.GetChildren()) {
            $this._statsPanel.RemoveChild($child)
        }
        
        # Add statistics labels
        $y = 1
        $statItems = @(
            @{Label="Total Tasks:"; Value=$stats.TotalTasks}
            @{Label="Pending:"; Value=$stats.TasksByStatus["Pending"]}
            @{Label="In Progress:"; Value=$stats.TasksByStatus["InProgress"]}
            @{Label="Completed:"; Value=$stats.TasksByStatus["Completed"]}
            @{Label="Projects:"; Value=$stats.TotalProjects}
        )
        
        foreach ($item in $statItems) {
            $label = [LabelComponent]::new("$($item.Label) $($item.Value)")
            $label.X = 2
            $label.Y = $y
            $label.Width = $this._statsPanel.GetContentWidth() - 4
            $this._statsPanel.AddChild($label)
            $y += 1
        }
        
        # Clear recent tasks panel
        foreach ($child in $this._recentTasksPanel.GetChildren()) {
            $this._recentTasksPanel.RemoveChild($child)
        }
        
        # Add recent tasks
        $recentTasks = $this._dataManager.GetTasks() | 
                       Where-Object { $_.Status -ne [TaskStatus]::Completed } |
                       Sort-Object UpdatedAt -Descending |
                       Select-Object -First 5
        
        $y = 1
        foreach ($task in $recentTasks) {
            $taskLabel = [LabelComponent]::new($task.Title)
            $taskLabel.X = 2
            $taskLabel.Y = $y
            $taskLabel.Width = $this._recentTasksPanel.GetContentWidth() - 4
            
            # Color based on priority
            $taskLabel.Style = @{
                FG = switch ($task.Priority) {
                    ([TaskPriority]::Critical) { "#FF0000" }
                    ([TaskPriority]::High) { "#FFA500" }
                    ([TaskPriority]::Medium) { "#FFFF00" }
                    default { "#C0C0C0" }
                }
            }
            
            $this._recentTasksPanel.AddChild($taskLabel)
            $y += 1
        }
        
        if ($recentTasks.Count -eq 0) {
            $noTasksLabel = [LabelComponent]::new("No pending tasks")
            $noTasksLabel.X = 2
            $noTasksLabel.Y = 1
            $noTasksLabel.Style = @{ FG = "#808080"; Italic = $true }
            $this._recentTasksPanel.AddChild($noTasksLabel)
        }
        
        $this.InvalidateRender()
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        # Handle focus navigation
        if ($key.Key -eq [ConsoleKey]::Tab) {
            if ($this._newTaskButton.Focused) {
                $this._newTaskButton.SetFocus($false)
                $this._viewTasksButton.SetFocus($true)
            } else {
                $this._viewTasksButton.SetFocus($false)
                $this._newTaskButton.SetFocus($true)
            }
            $this.InvalidateRender()
            return $true
        }
        
        # Let base class handle other input
        return ([Screen]$this).OnHandleInput($key)
    }
}