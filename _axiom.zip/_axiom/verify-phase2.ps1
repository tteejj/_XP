# Phase 2 Verification Script
# Tests UI components and services

Write-Host "`n=== Phase 2 Verification Script ===" -ForegroundColor Cyan
Write-Host "Testing UI components and services...`n" -ForegroundColor Yellow

# Load dependencies from Phase 1
. .\modules\core-utilities\core-utilities.psm1
. .\modules\models\models.psm1
. .\modules\event-system\event-system.psm1
. .\components\tui-primitives\tui-primitives.psm1
. .\modules\theme-manager\theme-manager.psm1
. .\components\ui-classes\ui-classes.psm1
. .\layout\panels-class\panels-class.psm1

$testResults = @()

# Test 1: TUI Components
Write-Host "Test 1: TUI Components" -ForegroundColor White
try {
    . .\components\tui-components\tui-components.psm1
    
    # Test Label
    $label = [LabelComponent]::new("Test Label")
    $label.Width = 20
    $label.Height = 1
    $label.Initialize()
    
    # Test Button
    $clicked = $false
    $button = [ButtonComponent]::new("Click Me", { $script:clicked = $true })
    $button.Initialize()
    
    # Test TextBox
    $textbox = [TextBoxComponent]::new("Enter text...")
    $textbox.Initialize()
    $textbox.SetText("Test")
    
    # Test CheckBox
    $checkbox = [CheckBoxComponent]::new("Check me")
    $checkbox.Initialize()
    
    if ($label.Text -eq "Test Label" -and $textbox.Text -eq "Test" -and $button.Width -gt 0) {
        Write-Host "✓ All UI components created successfully" -ForegroundColor Green
        $testResults += @{Test="TUI Components"; Result="PASS"; Details="Label, Button, TextBox, CheckBox work"}
    } else {
        throw "Component properties not set correctly"
    }
} catch {
    $testResults += @{Test="TUI Components"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 2: Navigation Service
Write-Host "`nTest 2: Navigation Service" -ForegroundColor White
try {
    . .\services\navigation-service-class\navigation-service-class.psm1
    
    $navService = [NavigationService]::new()
    
    # Register a test screen type
    $navService.RegisterRoute("/test", [DashboardScreen])
    
    # Test screen registry
    [ScreenRegistry]::Register("Dashboard", [DashboardScreen])
    $registeredScreens = [ScreenRegistry]::GetRegisteredScreens()
    
    if ($registeredScreens -contains "Dashboard") {
        Write-Host "✓ Navigation service and registry work" -ForegroundColor Green
        $testResults += @{Test="Navigation Service"; Result="PASS"; Details="Route registration works"}
    } else {
        throw "Screen registration failed"
    }
} catch {
    $testResults += @{Test="Navigation Service"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 3: Data Manager
Write-Host "`nTest 3: Data Manager" -ForegroundColor White
try {
    . .\modules\data-manager\data-manager.psm1
    
    # Create temp data file for testing
    $testPath = Join-Path $env:TEMP "pmc_test_data.json"
    $dataManager = [DataManager]::new($testPath)
    
    # Test project operations
    $project = [PmcProject]::new("TEST", "Test Project")
    $dataManager.AddProject($project)
    
    # Test task operations
    $task = [PmcTask]::new("Test Task", "Description", [TaskPriority]::High, "TEST")
    $dataManager.AddTask($task)
    
    $stats = $dataManager.GetStatistics()
    
    if ($stats.TotalProjects -ge 1 -and $stats.TotalTasks -ge 1) {
        Write-Host "✓ Data manager CRUD operations work" -ForegroundColor Green
        $testResults += @{Test="Data Manager"; Result="PASS"; Details="Projects and tasks management works"}
    } else {
        throw "Data operations failed"
    }
    
    # Cleanup
    $dataManager.Dispose()
    if (Test-Path $testPath) { Remove-Item $testPath -Force }
    
} catch {
    $testResults += @{Test="Data Manager"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 4: Keybinding Service
Write-Host "`nTest 4: Keybinding Service" -ForegroundColor White
try {
    . .\services\keybinding-service\keybinding-service.psm1
    
    $keybindingService = [KeybindingService]::new()
    
    # Test custom keybinding
    $testExecuted = $false
    $keybindingService.RegisterKeybinding([ConsoleKey]::T, [ConsoleModifiers]::Control, {
        $script:testExecuted = $true
    }, "Test binding")
    
    # Create test key press
    $testKey = [System.ConsoleKeyInfo]::new('T', [ConsoleKey]::T, $false, $false, $true)  # Ctrl+T
    $handled = $keybindingService.HandleKeyPress($testKey)
    
    if ($handled -and $testExecuted) {
        Write-Host "✓ Keybinding service works" -ForegroundColor Green
        $testResults += @{Test="Keybinding Service"; Result="PASS"; Details="Key registration and handling works"}
    } else {
        throw "Keybinding not executed"
    }
} catch {
    $testResults += @{Test="Keybinding Service"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 5: Dashboard Screen
Write-Host "`nTest 5: Dashboard Screen" -ForegroundColor White
try {
    . .\screens\dashboard\dashboard-screen.psm1
    
    # Create screen with injected services
    $screen = [DashboardScreen]::new()
    $screen.Width = 80
    $screen.Height = 24
    
    # Create mock services
    $navService = [NavigationService]::new()
    $dataManager = [DataManager]::new((Join-Path $env:TEMP "pmc_test_screen.json"))
    $themeEngine = Initialize-ThemeEngine
    
    $screen.InjectServices($navService, $dataManager, $themeEngine)
    $screen.Initialize()
    
    if ($null -ne $screen._private_buffer -and $screen.GetChildren().Count -gt 0) {
        Write-Host "✓ Dashboard screen initialization works" -ForegroundColor Green
        $testResults += @{Test="Dashboard Screen"; Result="PASS"; Details="Screen creates with panels and components"}
    } else {
        throw "Screen initialization failed"
    }
    
    # Cleanup
    $screen.Dispose()
    $dataManager.Dispose()
    
} catch {
    $testResults += @{Test="Dashboard Screen"; Result="FAIL"; Details=$_.Exception.Message}
}

# Test 6: Component Rendering
Write-Host "`nTest 6: Component Rendering" -ForegroundColor White
try {
    # Create a simple panel with components
    $panel = [Panel]::new("TestPanel", "Test Panel")
    $panel.Width = 40
    $panel.Height = 15
    $panel.Initialize()
    
    # Add components
    $label = [LabelComponent]::new("Test Label")
    $label.X = 2
    $label.Y = 2
    $label.Width = 30
    $label.Initialize()
    $panel.AddChild($label)
    
    $button = [ButtonComponent]::new("Test Button", {})
    $button.X = 2
    $button.Y = 4
    $button.Initialize()
    $panel.AddChild($button)
    
    # Render
    $panel.Render()
    
    # Check if buffer has content
    $hasContent = $false
    for ($y = 0; $y -lt $panel._private_buffer.Height; $y++) {
        for ($x = 0; $x -lt $panel._private_buffer.Width; $x++) {
            $cell = $panel._private_buffer.GetCell($x, $y)
            if ($null -ne $cell -and $cell.Char -ne ' ') {
                $hasContent = $true
                break
            }
        }
        if ($hasContent) { break }
    }
    
    if ($hasContent) {
        Write-Host "✓ Component rendering pipeline works" -ForegroundColor Green
        $testResults += @{Test="Component Rendering"; Result="PASS"; Details="Components render to buffers correctly"}
    } else {
        throw "No content rendered to buffer"
    }
} catch {
    $testResults += @{Test="Component Rendering"; Result="FAIL"; Details=$_.Exception.Message}
}

# Summary
Write-Host "`n=== Test Summary ===" -ForegroundColor Cyan
$passCount = ($testResults | Where-Object { $_.Result -eq "PASS" }).Count
$totalCount = $testResults.Count

foreach ($result in $testResults) {
    $color = if ($result.Result -eq "PASS") { "Green" } else { "Red" }
    Write-Host "$($result.Test): $($result.Result)" -ForegroundColor $color
    if ($result.Result -eq "FAIL") {
        Write-Host "  Details: $($result.Details)" -ForegroundColor DarkRed
    }
}

Write-Host "`nTotal: $passCount/$totalCount tests passed" -ForegroundColor $(if ($passCount -eq $totalCount) { "Green" } else { "Yellow" })

if ($passCount -eq $totalCount) {
    Write-Host "`n✅ Phase 2 complete!" -ForegroundColor Green
    Write-Host "All UI components and services are working correctly." -ForegroundColor Green
    Write-Host "The application now has:" -ForegroundColor Green
    Write-Host "  - Fully functional UI components (Label, Button, TextBox, CheckBox, etc.)" -ForegroundColor Green
    Write-Host "  - Navigation service with screen routing" -ForegroundColor Green
    Write-Host "  - Data persistence with task/project management" -ForegroundColor Green
    Write-Host "  - Global keybinding system" -ForegroundColor Green
    Write-Host "  - Working dashboard screen" -ForegroundColor Green
} else {
    Write-Host "`n⚠️  Some tests failed. Please review the errors above." -ForegroundColor Yellow
}