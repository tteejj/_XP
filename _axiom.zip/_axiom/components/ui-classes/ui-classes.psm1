# ==============================================================================
# UI Classes v3.2 - Resource-Managed Component Hierarchy
# ==============================================================================

class UIElement {
    [string] $Name = ""
    [int] $X = 0
    [int] $Y = 0
    [int] $Width = 0
    [int] $Height = 0
    [bool] $Visible = $true
    [bool] $Focused = $false
    hidden [TuiBuffer] $_private_buffer = $null
    hidden [UIElement] $_parent = $null
    hidden [System.Collections.Generic.List[UIElement]] $_children = [System.Collections.Generic.List[UIElement]]::new()
    hidden [hashtable] $_eventHandlers = @{}
    hidden [System.Collections.Generic.List[string]] $_subscriptions = [System.Collections.Generic.List[string]]::new()
    
    UIElement() { $this.Initialize() }
    
    # Lifecycle Methods
    [void] Initialize() {
        $this.OnInitialize()
        $this._private_buffer = [TuiBuffer]::new($this.Width, $this.Height, "$($this.Name).Buffer")
    }
    
    [void] Dispose() {
        $this.OnDispose()
        foreach ($sub in $this._subscriptions) { Unsubscribe-Event -HandlerId $sub }
        foreach ($child in $this._children) { $child.Dispose() }
        $this._children.Clear()
        $this._private_buffer = $null
    }
    
    # Hierarchy Management
    [void] AddChild([UIElement]$child) {
        if ($null -eq $child -or $child._parent -ne $null) { return }
        $child._parent = $this
        $this._children.Add($child)
        $this.OnChildAdded($child)
    }
    
    [void] RemoveChild([UIElement]$child) {
        if ($null -eq $child -or $child._parent -ne $this) { return }
        $child._parent = $null
        $this._children.Remove($child) | Out-Null
        $this.OnChildRemoved($child)
    }
    
    [UIElement[]] GetChildren() { return $this._children.ToArray() }
    [UIElement] GetParent() { return $this._parent }
    
    # Rendering Pipeline
    [void] Render() {
        if (-not $this.Visible -or $this.Width -le 0 -or $this.Height -le 0) { return }
        
        # Ensure buffer exists and is correct size
        if ($null -eq $this._private_buffer -or $this._private_buffer.Width -ne $this.Width -or $this._private_buffer.Height -ne $this.Height) {
            $this._private_buffer = [TuiBuffer]::new($this.Width, $this.Height, "$($this.Name).Buffer")
        }
        
        # Clear and render self
        $this._private_buffer.Clear()
        $this.OnRender()
        
        # Render children into this buffer
        foreach ($child in $this._children) {
            if ($child.Visible) {
                $child.Render()
                if ($null -ne $child._private_buffer) {
                    $this._private_buffer.BlendBuffer($child._private_buffer, $child.X, $child.Y)
                }
            }
        }
    }
    
    # Event Handling
    [bool] HandleInput([ConsoleKeyInfo]$key) {
        # First give focused children a chance
        foreach ($child in $this._children) {
            if ($child.Focused -and $child.HandleInput($key)) { return $true }
        }
        # Then handle in self
        return $this.OnHandleInput($key)
    }
    
    # Event Subscription Helper
    [void] SubscribeToEvent([string]$eventName, [scriptblock]$handler) {
        $id = Subscribe-Event -EventName $eventName -Handler $handler -Source $this.Name
        $this._subscriptions.Add($id)
    }
    
    # Virtual Methods for Override
    [void] OnInitialize() {}
    [void] OnDispose() {}
    [void] OnRender() {}
    [bool] OnHandleInput([ConsoleKeyInfo]$key) { return $false }
    [void] OnChildAdded([UIElement]$child) {}
    [void] OnChildRemoved([UIElement]$child) {}
    [void] OnResize([int]$oldWidth, [int]$oldHeight) {}
    
    # Focus Management
    [void] SetFocus([bool]$focused) {
        if ($this.Focused -eq $focused) { return }
        $this.Focused = $focused
        $this.OnFocusChanged($focused)
    }
    
    [void] OnFocusChanged([bool]$focused) {}
    
    # Utility Methods
    [void] InvalidateRender() {
        if ($null -ne $this._parent) { $this._parent.InvalidateRender() }
    }
    
    [void] Resize([int]$newWidth, [int]$newHeight) {
        $oldWidth = $this.Width
        $oldHeight = $this.Height
        $this.Width = $newWidth
        $this.Height = $newHeight
        if ($null -ne $this._private_buffer) {
            $this._private_buffer.Resize($newWidth, $newHeight)
        }
        $this.OnResize($oldWidth, $oldHeight)
    }
}

# Base Component Class
class Component : UIElement {
    [hashtable] $Style = @{}
    
    Component() : base() {}
    Component([string]$name) : base() { $this.Name = $name }
    
    [void] OnInitialize() {
        $this.LoadDefaultStyle()
    }
    
    [void] LoadDefaultStyle() {
        # Override in derived classes to set default styles
    }
}

# Base Panel Class (Container)
class Panel : Component {
    [string] $Title = ""
    [bool] $ShowBorder = $true
    [string] $BorderStyle = "Single"
    hidden [int] $_contentOffsetX = 1
    hidden [int] $_contentOffsetY = 1
    
    Panel() : base() {}
    Panel([string]$name, [string]$title) : base($name) { $this.Title = $title }
    
    [void] OnRender() {
        if ($this.ShowBorder -and $null -ne $this._private_buffer) {
            $borderStyle = @{
                BorderStyle = $this.BorderStyle
                BorderFG = $this.Style.BorderFG ?? "#808080"
                BG = $this.Style.BG ?? $null
                TitleFG = $this.Style.TitleFG ?? "#FFFFFF"
            }
            Write-TuiBox -B $this._private_buffer -X 0 -Y 0 -W $this.Width -H $this.Height -Title $this.Title -S $borderStyle
        }
    }
    
    [int] GetContentX() { return $this.ShowBorder ? $this._contentOffsetX : 0 }
    [int] GetContentY() { return $this.ShowBorder ? $this._contentOffsetY : 0 }
    [int] GetContentWidth() { return $this.ShowBorder ? ($this.Width - 2) : $this.Width }
    [int] GetContentHeight() { return $this.ShowBorder ? ($this.Height - 2) : $this.Height }
}

# Base Screen Class
class Screen : UIElement {
    [string] $Route = ""
    hidden [NavigationService] $_navigationService = $null
    hidden [DataManager] $_dataManager = $null
    hidden [ThemeEngine] $_themeEngine = $null
    
    Screen() : base() {}
    Screen([string]$name, [string]$route) : base() {
        $this.Name = $name
        $this.Route = $route
    }
    
    [void] InjectServices([NavigationService]$nav, [DataManager]$data, [ThemeEngine]$theme) {
        $this._navigationService = $nav
        $this._dataManager = $data
        $this._themeEngine = $theme
        $this.OnServicesInjected()
    }
    
    [void] OnServicesInjected() {}
    
    [void] OnScreenActivated() {}
    [void] OnScreenDeactivated() {}
}