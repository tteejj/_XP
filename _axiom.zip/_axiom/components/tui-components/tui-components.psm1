# ==============================================================================
# TUI Components v3.2 - Core UI Widget Library
# ==============================================================================

# Label Component
class LabelComponent : Component {
    [string] $Text = ""
    [string] $TextAlign = "Left"  # Left, Center, Right
    
    LabelComponent() : base() { $this.Height = 1 }
    LabelComponent([string]$text) : base() { 
        $this.Text = $text
        $this.Height = 1
        $this.Width = $text.Length
    }
    
    [void] OnRender() {
        if ([string]::IsNullOrEmpty($this.Text) -or $null -eq $this._private_buffer) { return }
        
        $style = @{
            FG = $this.Style.FG ?? "#C0C0C0"
            BG = $this.Style.BG ?? $null
            Bold = $this.Style.Bold ?? $false
            Italic = $this.Style.Italic ?? $false
            Underline = $this.Style.Underline ?? $false
        }
        
        # Calculate text position based on alignment
        $x = 0
        switch ($this.TextAlign) {
            "Center" { $x = [Math]::Max(0, [Math]::Floor(($this.Width - $this.Text.Length) / 2)) }
            "Right" { $x = [Math]::Max(0, $this.Width - $this.Text.Length) }
        }
        
        # Truncate text if needed
        $displayText = if ($this.Text.Length -gt $this.Width) {
            $this.Text.Substring(0, [Math]::Max(0, $this.Width - 3)) + "..."
        } else {
            $this.Text
        }
        
        Write-TuiText -B $this._private_buffer -X $x -Y 0 -T $displayText -S $style
    }
}

# Button Component
class ButtonComponent : Component {
    [string] $Text = "Button"
    [scriptblock] $OnClick = {}
    [bool] $IsDefault = $false
    
    ButtonComponent() : base() { $this.Height = 3 }
    ButtonComponent([string]$text, [scriptblock]$onClick) : base() {
        $this.Text = $text
        $this.OnClick = $onClick
        $this.Width = [Math]::Max(10, $text.Length + 6)
        $this.Height = 3
    }
    
    [void] LoadDefaultStyle() {
        $this.Style = @{
            FG = "#FFFFFF"
            BG = "#0066CC"
            BorderStyle = "Rounded"
            FocusedBG = "#0088FF"
            FocusedFG = "#FFFFFF"
            DisabledFG = "#808080"
            DisabledBG = "#404040"
        }
    }
    
    [void] OnRender() {
        if ($null -eq $this._private_buffer) { return }
        
        # Determine colors based on state
        $fg = $this.Style.FG
        $bg = $this.Style.BG
        $borderStyle = $this.Style.BorderStyle ?? "Rounded"
        
        if ($this.Focused) {
            $fg = $this.Style.FocusedFG ?? $fg
            $bg = $this.Style.FocusedBG ?? "#0088FF"
        }
        
        # Draw button background
        $boxStyle = @{
            BorderStyle = $borderStyle
            BorderFG = $fg
            BG = $bg
        }
        Write-TuiBox -B $this._private_buffer -X 0 -Y 0 -W $this.Width -H $this.Height -S $boxStyle
        
        # Draw button text centered
        $textX = [Math]::Floor(($this.Width - $this.Text.Length) / 2)
        $textY = 1
        $textStyle = @{ FG = $fg; BG = $bg; Bold = $true }
        Write-TuiText -B $this._private_buffer -X $textX -Y $textY -T $this.Text -S $textStyle
        
        # Draw focus indicator
        if ($this.Focused) {
            Write-TuiText -B $this._private_buffer -X 2 -Y 1 -T ">" -S @{FG=$fg;BG=$bg}
            Write-TuiText -B $this._private_buffer -X ($this.Width - 3) -Y 1 -T "<" -S @{FG=$fg;BG=$bg}
        }
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        if ($key.Key -eq [ConsoleKey]::Enter -or $key.Key -eq [ConsoleKey]::Spacebar) {
            if ($null -ne $this.OnClick) {
                & $this.OnClick
            }
            return $true
        }
        return $false
    }
}

# TextBox Component
class TextBoxComponent : Component {
    [string] $Text = ""
    [string] $Placeholder = ""
    [int] $MaxLength = 100
    [bool] $IsPassword = $false
    hidden [int] $_cursorPosition = 0
    hidden [int] $_viewOffset = 0
    
    TextBoxComponent() : base() { $this.Height = 3 }
    TextBoxComponent([string]$placeholder) : base() {
        $this.Placeholder = $placeholder
        $this.Height = 3
        $this.Width = 30
    }
    
    [void] LoadDefaultStyle() {
        $this.Style = @{
            FG = "#FFFFFF"
            BG = "#1A1A1A"
            BorderFG = "#606060"
            FocusedBorderFG = "#0088FF"
            PlaceholderFG = "#808080"
            CursorFG = "#FFFFFF"
            CursorBG = "#0088FF"
        }
    }
    
    [void] OnRender() {
        if ($null -eq $this._private_buffer) { return }
        
        # Border color changes when focused
        $borderFG = if ($this.Focused) { $this.Style.FocusedBorderFG } else { $this.Style.BorderFG }
        
        # Draw textbox border
        $boxStyle = @{
            BorderStyle = "Single"
            BorderFG = $borderFG
            BG = $this.Style.BG
        }
        Write-TuiBox -B $this._private_buffer -X 0 -Y 0 -W $this.Width -H $this.Height -S $boxStyle
        
        # Prepare display text
        $displayText = if ($this.IsPassword -and $this.Text.Length -gt 0) {
            "*" * $this.Text.Length
        } else {
            $this.Text
        }
        
        # Calculate visible portion
        $visibleWidth = $this.Width - 4  # Account for borders and padding
        $this.AdjustViewOffset($visibleWidth)
        
        # Draw text or placeholder
        if ($displayText.Length -gt 0) {
            $visibleText = if ($displayText.Length -gt $this._viewOffset) {
                $endIndex = [Math]::Min($displayText.Length, $this._viewOffset + $visibleWidth)
                $displayText.Substring($this._viewOffset, $endIndex - $this._viewOffset)
            } else { "" }
            
            Write-TuiText -B $this._private_buffer -X 2 -Y 1 -T $visibleText -S @{FG=$this.Style.FG;BG=$this.Style.BG}
        } elseif (-not [string]::IsNullOrEmpty($this.Placeholder) -and -not $this.Focused) {
            $placeholderText = if ($this.Placeholder.Length -gt $visibleWidth) {
                $this.Placeholder.Substring(0, $visibleWidth - 3) + "..."
            } else { $this.Placeholder }
            
            Write-TuiText -B $this._private_buffer -X 2 -Y 1 -T $placeholderText -S @{FG=$this.Style.PlaceholderFG;BG=$this.Style.BG}
        }
        
        # Draw cursor when focused
        if ($this.Focused) {
            $cursorScreenPos = $this._cursorPosition - $this._viewOffset + 2
            if ($cursorScreenPos -ge 2 -and $cursorScreenPos -lt ($this.Width - 2)) {
                # Draw cursor character
                $cursorChar = if ($this._cursorPosition -lt $displayText.Length) {
                    $displayText[$this._cursorPosition]
                } else { ' ' }
                
                Write-TuiText -B $this._private_buffer -X $cursorScreenPos -Y 1 -T $cursorChar -S @{FG=$this.Style.CursorFG;BG=$this.Style.CursorBG}
            }
        }
    }
    
    hidden [void] AdjustViewOffset([int]$visibleWidth) {
        # Ensure cursor is visible
        if ($this._cursorPosition -lt $this._viewOffset) {
            $this._viewOffset = $this._cursorPosition
        } elseif ($this._cursorPosition -ge ($this._viewOffset + $visibleWidth)) {
            $this._viewOffset = $this._cursorPosition - $visibleWidth + 1
        }
        
        # Ensure view offset is valid
        $this._viewOffset = [Math]::Max(0, $this._viewOffset)
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        $handled = $true
        
        switch ($key.Key) {
            ([ConsoleKey]::LeftArrow) {
                if ($this._cursorPosition -gt 0) {
                    $this._cursorPosition--
                    $this.InvalidateRender()
                }
            }
            ([ConsoleKey]::RightArrow) {
                if ($this._cursorPosition -lt $this.Text.Length) {
                    $this._cursorPosition++
                    $this.InvalidateRender()
                }
            }
            ([ConsoleKey]::Home) {
                $this._cursorPosition = 0
                $this.InvalidateRender()
            }
            ([ConsoleKey]::End) {
                $this._cursorPosition = $this.Text.Length
                $this.InvalidateRender()
            }
            ([ConsoleKey]::Backspace) {
                if ($this._cursorPosition -gt 0) {
                    $this.Text = $this.Text.Remove($this._cursorPosition - 1, 1)
                    $this._cursorPosition--
                    $this.InvalidateRender()
                    Publish-Event -EventName "TextBox.Changed" -Data @{Component=$this;Text=$this.Text}
                }
            }
            ([ConsoleKey]::Delete) {
                if ($this._cursorPosition -lt $this.Text.Length) {
                    $this.Text = $this.Text.Remove($this._cursorPosition, 1)
                    $this.InvalidateRender()
                    Publish-Event -EventName "TextBox.Changed" -Data @{Component=$this;Text=$this.Text}
                }
            }
            default {
                if ($key.KeyChar -and $key.KeyChar -ne 0 -and $this.Text.Length -lt $this.MaxLength) {
                    $this.Text = $this.Text.Insert($this._cursorPosition, $key.KeyChar)
                    $this._cursorPosition++
                    $this.InvalidateRender()
                    Publish-Event -EventName "TextBox.Changed" -Data @{Component=$this;Text=$this.Text}
                } else {
                    $handled = $false
                }
            }
        }
        
        return $handled
    }
    
    [void] SetText([string]$text) {
        $this.Text = if ($text.Length -gt $this.MaxLength) {
            $text.Substring(0, $this.MaxLength)
        } else { $text }
        $this._cursorPosition = $this.Text.Length
        $this.InvalidateRender()
    }
}

# CheckBox Component
class CheckBoxComponent : Component {
    [bool] $Checked = $false
    [string] $Label = ""
    [scriptblock] $OnChange = {}
    
    CheckBoxComponent() : base() { $this.Height = 1 }
    CheckBoxComponent([string]$label) : base() {
        $this.Label = $label
        $this.Height = 1
        $this.Width = $label.Length + 4
    }
    
    [void] LoadDefaultStyle() {
        $this.Style = @{
            FG = "#C0C0C0"
            CheckedFG = "#00FF00"
            FocusedFG = "#FFFFFF"
            BoxFG = "#808080"
            FocusedBoxFG = "#0088FF"
        }
    }
    
    [void] OnRender() {
        if ($null -eq $this._private_buffer) { return }
        
        $boxFG = if ($this.Focused) { $this.Style.FocusedBoxFG } else { $this.Style.BoxFG }
        $labelFG = if ($this.Focused) { $this.Style.FocusedFG } else { $this.Style.FG }
        
        # Draw checkbox
        $checkChar = if ($this.Checked) { "✓" } else { " " }
        $checkFG = if ($this.Checked) { $this.Style.CheckedFG } else { $boxFG }
        
        Write-TuiText -B $this._private_buffer -X 0 -Y 0 -T "[" -S @{FG=$boxFG}
        Write-TuiText -B $this._private_buffer -X 1 -Y 0 -T $checkChar -S @{FG=$checkFG;Bold=$true}
        Write-TuiText -B $this._private_buffer -X 2 -Y 0 -T "]" -S @{FG=$boxFG}
        
        # Draw label
        if (-not [string]::IsNullOrEmpty($this.Label)) {
            Write-TuiText -B $this._private_buffer -X 4 -Y 0 -T $this.Label -S @{FG=$labelFG}
        }
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        if ($key.Key -eq [ConsoleKey]::Spacebar -or $key.Key -eq [ConsoleKey]::Enter) {
            $this.Toggle()
            return $true
        }
        return $false
    }
    
    [void] Toggle() {
        $this.Checked = -not $this.Checked
        $this.InvalidateRender()
        if ($null -ne $this.OnChange) {
            & $this.OnChange $this.Checked
        }
        Publish-Event -EventName "CheckBox.Changed" -Data @{Component=$this;Checked=$this.Checked}
    }
}

# RadioButton Component
class RadioButtonComponent : Component {
    [bool] $Selected = $false
    [string] $Label = ""
    [string] $GroupName = ""
    [scriptblock] $OnSelect = {}
    
    RadioButtonComponent() : base() { $this.Height = 1 }
    RadioButtonComponent([string]$label, [string]$groupName) : base() {
        $this.Label = $label
        $this.GroupName = $groupName
        $this.Height = 1
        $this.Width = $label.Length + 4
    }
    
    [void] LoadDefaultStyle() {
        $this.Style = @{
            FG = "#C0C0C0"
            SelectedFG = "#00FF00"
            FocusedFG = "#FFFFFF"
            BoxFG = "#808080"
            FocusedBoxFG = "#0088FF"
        }
    }
    
    [void] OnRender() {
        if ($null -eq $this._private_buffer) { return }
        
        $boxFG = if ($this.Focused) { $this.Style.FocusedBoxFG } else { $this.Style.BoxFG }
        $labelFG = if ($this.Focused) { $this.Style.FocusedFG } else { $this.Style.FG }
        
        # Draw radio button
        $selectChar = if ($this.Selected) { "●" } else { " " }
        $selectFG = if ($this.Selected) { $this.Style.SelectedFG } else { $boxFG }
        
        Write-TuiText -B $this._private_buffer -X 0 -Y 0 -T "(" -S @{FG=$boxFG}
        Write-TuiText -B $this._private_buffer -X 1 -Y 0 -T $selectChar -S @{FG=$selectFG;Bold=$true}
        Write-TuiText -B $this._private_buffer -X 2 -Y 0 -T ")" -S @{FG=$boxFG}
        
        # Draw label
        if (-not [string]::IsNullOrEmpty($this.Label)) {
            Write-TuiText -B $this._private_buffer -X 4 -Y 0 -T $this.Label -S @{FG=$labelFG}
        }
    }
    
    [bool] OnHandleInput([ConsoleKeyInfo]$key) {
        if ($key.Key -eq [ConsoleKey]::Spacebar -or $key.Key -eq [ConsoleKey]::Enter) {
            $this.Select()
            return $true
        }
        return $false
    }
    
    [void] Select() {
        if (-not $this.Selected) {
            # Deselect all other radio buttons in the same group
            if (-not [string]::IsNullOrEmpty($this.GroupName)) {
                Publish-Event -EventName "RadioButton.GroupSelect" -Data @{
                    GroupName = $this.GroupName
                    SelectedComponent = $this
                }
            }
            
            $this.Selected = $true
            $this.InvalidateRender()
            
            if ($null -ne $this.OnSelect) {
                & $this.OnSelect
            }
        }
    }
    
    [void] Deselect() {
        $this.Selected = $false
        $this.InvalidateRender()
    }
}

# ProgressBar Component
class ProgressBarComponent : Component {
    [int] $Value = 0
    [int] $Maximum = 100
    [string] $DisplayFormat = "Percentage"  # Percentage, Fraction, Both, None
    [bool] $ShowBorder = $true
    
    ProgressBarComponent() : base() { $this.Height = 3 }
    ProgressBarComponent([int]$max) : base() {
        $this.Maximum = $max
        $this.Height = 3
        $this.Width = 30
    }
    
    [void] LoadDefaultStyle() {
        $this.Style = @{
            FG = "#00FF00"
            BG = "#1A1A1A"
            BorderFG = "#606060"
            BarChar = "█"
            EmptyChar = "░"
        }
    }
    
    [void] OnRender() {
        if ($null -eq $this._private_buffer) { return }
        
        # Draw border if enabled
        if ($this.ShowBorder) {
            $boxStyle = @{
                BorderStyle = "Single"
                BorderFG = $this.Style.BorderFG
                BG = $this.Style.BG
            }
            Write-TuiBox -B $this._private_buffer -X 0 -Y 0 -W $this.Width -H $this.Height -S $boxStyle
        }
        
        # Calculate progress
        $percentage = if ($this.Maximum -gt 0) {
            [Math]::Min(100, [Math]::Max(0, [int](($this.Value / $this.Maximum) * 100)))
        } else { 0 }
        
        $barWidth = if ($this.ShowBorder) { $this.Width - 2 } else { $this.Width }
        $barY = if ($this.ShowBorder) { 1 } else { 0 }
        $barX = if ($this.ShowBorder) { 1 } else { 0 }
        
        $filledWidth = [int](($percentage / 100) * $barWidth)
        
        # Draw progress bar
        $barText = ($this.Style.BarChar * $filledWidth).PadRight($barWidth, $this.Style.EmptyChar)
        
        for ($i = 0; $i -lt $barText.Length; $i++) {
            $char = $barText[$i]
            $fg = if ($i -lt $filledWidth) { $this.Style.FG } else { $this.Style.BorderFG }
            Write-TuiText -B $this._private_buffer -X ($barX + $i) -Y $barY -T $char -S @{FG=$fg;BG=$this.Style.BG}
        }
        
        # Draw text overlay
        $text = switch ($this.DisplayFormat) {
            "Percentage" { "$percentage%" }
            "Fraction" { "$($this.Value)/$($this.Maximum)" }
            "Both" { "$($this.Value)/$($this.Maximum) ($percentage%)" }
            default { "" }
        }
        
        if (-not [string]::IsNullOrEmpty($text)) {
            $textX = $barX + [Math]::Floor(($barWidth - $text.Length) / 2)
            Write-TuiText -B $this._private_buffer -X $textX -Y $barY -T $text -S @{FG="#FFFFFF";BG=$null;Bold=$true}
        }
    }
    
    [void] SetValue([int]$value) {
        $this.Value = [Math]::Max(0, [Math]::Min($this.Maximum, $value))
        $this.InvalidateRender()
    }
}